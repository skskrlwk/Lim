package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;

public class MemberDeleteAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		MemberDAO mdao = new MemberDAO();
		
		String idx = req.getParameter("idx");
		int n = mdao.deleteMember(idx);
		
		String msg = "";
		String loc = "javascript:history.back()";
		
		
		if(n == 0) {
			msg ="삭제하기 실패!!";
		}else {
			msg = "삭제하기 성공!!!";
		}
		
		
		req.setAttribute("msg", msg);
		req.setAttribute("loc", loc);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/msg.jsp");
		
		
		
	}

}
