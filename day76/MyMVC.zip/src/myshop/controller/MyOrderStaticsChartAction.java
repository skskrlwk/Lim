package myshop.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.InterProductDAO;
import myshop.model.ProductDAO;

public class MyOrderStaticsChartAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		MemberVO loginuser = super.getMemberLogin(req);
		
		if(loginuser == null) {
			return;
		}
		
		InterProductDAO pdao = new ProductDAO();
		
		List<HashMap<String, String>> maplist = pdao.getMyOrderStatics(loginuser.getUserid());
		JSONArray jsonarr = new JSONArray();
		
		if(maplist != null && maplist.size() > 0) {
			
			for(HashMap<String, String> map : maplist) {
				
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("cname", map.get("cname"));
				jsonObj.put("sumjumunprice", map.get("sumjumunprice"));
				jsonObj.put("percent", map.get("percent"));
				jsonarr.add(jsonObj);
				
			}
		}
		
		String str_jsonArray = jsonarr.toString();
		System.out.println(">>>>>>>>>> 확인용 str_jsonArray :"+str_jsonArray);
		// [{"sumjumunprice":"9300000","cname":"전자제품","percent":"91.5"},{"sumjumunprice":"699000","cname":"도서","percent":"6.9"},{"sumjumunprice":"164000","cname":"의류","percent":"1.6"}]
		
		req.setAttribute("str_jsonArray", str_jsonArray);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/myOrderStaticsChart.jsp");
		
	}

}