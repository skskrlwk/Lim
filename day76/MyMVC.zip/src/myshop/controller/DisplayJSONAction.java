package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import common.controller.AbstractController;
import myshop.model.InterProductDAO;
import myshop.model.ProductDAO;
import myshop.model.ProductVO;
import util.my.MyUtil;

public class DisplayJSONAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String start = req.getParameter("start"); 
		String len = req.getParameter("len"); 
		String pspec = req.getParameter("pspec");
		
		if(start == null || start.trim().isEmpty()) {
			start = "1";
		}
		
		if(len == null || len.trim().isEmpty()) {
			len = "3";
		}
		
		if(pspec == null || pspec.trim().isEmpty()) {
			pspec = "HIT";
		}
		
		System.out.println(">>>>>>>> 확인용 " + start + ", " + len + ", " + pspec);
		
		int startRno = Integer.parseInt(start);
		// 시작행번호
		
		int endRno = startRno + Integer.parseInt(len) - 1;
		// 끝행번호 공식 !! 
		
		InterProductDAO pdao = new ProductDAO();
		List<ProductVO> productList = pdao.getProductVOListByPspec(pspec, startRno, endRno);
		JSONArray jsonArr = new JSONArray();
		
		if(productList != null && productList.size() > 0) {
			
			for(ProductVO vo : productList) {
				JSONObject obj = new JSONObject();
				obj.put("pnum", vo.getPnum());
				obj.put("pname", vo.getPname());
				obj.put("pcategory", vo.getPcategory_fk());
				obj.put("pcompany", vo.getPcompany());
				obj.put("pqty", vo.getPqty());
				obj.put("pspec", vo.getPspec());
				obj.put("price", MyUtil.getMoney(vo.getPrice()));
				obj.put("saleprice", MyUtil.getMoney(vo.getSaleprice()));
				obj.put("pimage1", vo.getPimage1());
				obj.put("pimage2", vo.getPimage2());
				obj.put("point", MyUtil.getMoney(vo.getPoint()));
				obj.put("pcontent", vo.getPcontent());
				obj.put("pinputdate", vo.getPinputdate());
				obj.put("percent", vo.getPercent());
				
				jsonArr.add(obj);
			}
			
		}
		
		String str_jsonArr = jsonArr.toString();
		
		req.setAttribute("str_jsonArr", str_jsonArr);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/malldisplayJSON.jsp");

	}

}
