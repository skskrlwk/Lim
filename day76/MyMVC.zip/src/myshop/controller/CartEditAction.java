package myshop.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.ProductDAO;

public class CartEditAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String method = req.getMethod();
		String oqty = req.getParameter("oqty");
		String cartno = req.getParameter("cartno");
		String goBackURL = req.getParameter("goBackURL");
		
		MemberVO loginuser = super.getMemberLogin(req);
		// 로그인 유무 검사해주는 메소드 호출
		
		if(loginuser == null) {
			return;
			
		} else if(!"post".equalsIgnoreCase(method)) {
			// post 형식이 아닐떄
			super.invalidPath(req);
			return;
		}
				
		ProductDAO dao = new ProductDAO();
		int n = dao.oqtyUpdate(loginuser.getUserid(), cartno, oqty);
		
		if(n > 0) {
			super.alertMsg(req, "수정하기 완료!!", goBackURL);
		}else {
			super.alertMsg(req, "수정하기 실패!!", "javascript:history.back();");
		}

	}

}
