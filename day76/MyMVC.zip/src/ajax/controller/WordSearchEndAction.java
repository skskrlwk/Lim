package ajax.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;

import ajax.model.AjaxDAO;
import ajax.model.InterAjaxDAO;
import common.controller.AbstractController;

public class WordSearchEndAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {

		String searchword = req.getParameter("searchword");
		InterAjaxDAO adao = new AjaxDAO();
		List<Map<String, String>> mapList = adao.getContentMSG(searchword);
		// 메소드 구현하기
		
		
		
		req.setAttribute("mapList", mapList);
		
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap5/wordSearchEnd.jsp");

	}

}
