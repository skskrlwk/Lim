package ajax.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import ajax.model.AjaxDAO;
import ajax.model.BookVO;
import ajax.model.InterAjaxDAO;
import common.controller.AbstractController;

public class SecondNewBooksInfoJSONAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		InterAjaxDAO ajaxdao = new AjaxDAO();
		List<BookVO> listbooks = ajaxdao.getAllBooks(2);
		
		JSONArray jsonArr = new JSONArray();
		
		if(listbooks != null && listbooks.size() > 0) {
			for(BookVO vo : listbooks) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("subject", vo.getSubject());
				jsonObj.put("title", vo.getTitle());
				jsonObj.put("registerday", vo.getRegisterday());
				jsonObj.put("author", vo.getAuthor());
			
				jsonArr.add(jsonObj);	
			}
		}
		
		String str_jsonArr = jsonArr.toString();
		req.setAttribute("str_jsonArr", str_jsonArr);
		
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/2NewbooksInfoJSON.jsp");
		
	}

}
