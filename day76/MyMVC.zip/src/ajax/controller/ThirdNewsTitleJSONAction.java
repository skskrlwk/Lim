package ajax.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import ajax.model.AjaxDAO;
import ajax.model.InterAjaxDAO;
import ajax.model.TodayNewsVO;
import common.controller.AbstractController;

public class ThirdNewsTitleJSONAction extends AbstractController{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		InterAjaxDAO adao = new AjaxDAO();
		
		List<TodayNewsVO> newsTitleList = adao.getNewsTitleList();
		
		JSONArray jsonArr = new JSONArray();
		
		if(newsTitleList != null && newsTitleList.size() > 0) {
			
			for(TodayNewsVO vo : newsTitleList) {
				JSONObject obj = new JSONObject();
				obj.put("title", vo.getTitle());
				obj.put("registerday", vo.getRegisterday());
				obj.put("seqtitleno", vo.getSeqtitleno());
				
				jsonArr.add(obj);
			}
			
		}
		
		
		req.setAttribute("jsonArr", jsonArr);
		
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/3newsTitle.jsp");
		
	}

}
