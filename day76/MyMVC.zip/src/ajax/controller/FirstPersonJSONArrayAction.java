package ajax.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import common.controller.AbstractController;

public class FirstPersonJSONArrayAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		JSONObject PersonObj1 = new JSONObject();
		
		PersonObj1.put("name", "이순신");
		PersonObj1.put("age", new Integer(27));
		PersonObj1.put("height", new Double(171.5));
		PersonObj1.put("phone", "010-345-6789");
		PersonObj1.put("email", "leess@gmail.com");
		PersonObj1.put("address", "서울시 강남구 도곡동");
		
		JSONObject PersonObj2 = new JSONObject();
		
		PersonObj2.put("name", "엄정화");
		PersonObj2.put("age", new Integer(45));
		PersonObj2.put("height", new Double(167.8));
		PersonObj2.put("phone", "010-333-2222");
		PersonObj2.put("email", "eom@gmail.com");
		PersonObj2.put("address", "서울시 영등포구 당산동");
		
		JSONObject PersonObj3 = new JSONObject();
		
		PersonObj3.put("name", "안중근");
		PersonObj3.put("age", new Integer(32));
		PersonObj3.put("height", new Double(178.3));
		PersonObj3.put("phone", "010-111-1111");
		PersonObj3.put("email", "ahn@gmail.com");
		PersonObj3.put("address", "서울시 군포시 좋은동");
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(PersonObj1);
		jsonArray.add(PersonObj2);
		jsonArray.add(PersonObj3);
		
		String str_jsonArray = jsonArray.toString();
		// JSONArray jsonArray 을 String 으로 변환하기
		
		System.out.println("===> 확인용 JSONArray 형태의 str_jsonArray 의 값 : " + str_jsonArray);
		// [{"address":"서울시 강남구 도곡동","phone":"010-345-6789","name":"이순신","age":27,"email":"leess@gmail.com","height":171.5},
		//  {"address":"서울시 영등포구 당산동","phone":"010-333-2222","name":"엄정화","age":45,"email":"eom@gmail.com","height":167.8},
		//  {"address":"서울시 군포시 좋은동","phone":"010-111-1111","name":"안중근","age":32,"email":"ahn@gmail.com","height":178.3}]
		
		req.setAttribute("str_jsonArray", str_jsonArray);
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/1personArrInfoJSON.jsp");
		
	}

}
