package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class MemberRegisterEndAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String name = req.getParameter("name");
		String userid = req.getParameter("userid");
		String pwd = req.getParameter("pwd");
		String email = req.getParameter("email");
		String hp1 = req.getParameter("hp1");
		String hp2 = req.getParameter("hp2");
		String hp3 = req.getParameter("hp3");
		String post1 = req.getParameter("post1");
		String post2 = req.getParameter("post2");
		String addr1 = req.getParameter("addr1");
		String addr2 = req.getParameter("addr2");
		
		MemberVO mvo = new MemberVO();
		mvo.setName(name);
		mvo.setUserid(userid);
		mvo.setPwd(pwd);
		mvo.setEmail(email);
		mvo.setHp1(hp1);
		mvo.setHp2(hp2);
		mvo.setHp3(hp3);
		mvo.setPost1(post1);
		mvo.setPost2(post2);
		mvo.setAddr1(addr1);
		mvo.setAddr2(addr2);
		
		int n = 0;
		MemberDAO mdao = new MemberDAO();
		
		n = mdao.registerMember(mvo);
		if(n == 1) {
			req.setAttribute("msg", "회원가입 성공!!");
			req.setAttribute("loc", "javascript:history.back();");
		}else {
			req.setAttribute("msg", "회원가입 실패!!");
			req.setAttribute("loc", "javascript:history.back();");
		}
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/msg.jsp");
		
	}

}
