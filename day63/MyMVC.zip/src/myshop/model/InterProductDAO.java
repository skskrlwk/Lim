package myshop.model;

import java.sql.SQLException;
import java.util.*;

public interface InterProductDAO {

	
	// *** jsp_product 테이블에서  pspec 컬럼의 값(HIT, NEW, BEST)별로 상품목로드를 가져오는 추상메소드 *** //
	List<ProductVO> selectByPspec(String pspec) throws SQLException;
	
}
