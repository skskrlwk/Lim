package member.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class LoginEndAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
				
		String method = req.getMethod();
		MemberVO membervo = null;
		
		if(!method.equalsIgnoreCase("post")) {
			// POST 방식으로 넘어온것이 아니라면
			String msg = "비정상적인 경로로 들어왔습니다.";
			String loc = "javascript:history.back()";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			
			
		}else {
			// POST 방식으로 넘어온 것
			String userid = req.getParameter("userid");
			String pwd = req.getParameter("pwd");
			
			String goBackURL = req.getParameter("goBackURL");
			String saveid = req.getParameter("saveid");
			// checkbox 에 value 값이 없을 경우
			// 체크가 된 상태로 넘어오면 'on' 으로 받아오고
			// 체크가 안된 상태로 넘어오면 null 로 받아온다!!!!!
			
			System.out.println("===> 확인용 saveid : " + saveid);
			
			// 사용자로 부터 입력받은 userid 와 pwd 값이
			// jsp_member 테이블에 존재하는지 여부를 알아야 한다.
			MemberDAO memberdao = new MemberDAO();
			
			membervo= memberdao.loginOKmemberInfo(userid, pwd);
			
			if(membervo == null) {
				// 로그인 실패
				String msg = "아이디 또는 비밀번호가 틀렸습니다.";
				String loc = "javascript:history.back()";
				
				req.setAttribute("msg", msg);
				req.setAttribute("loc", loc);
				
				super.setRedirect(false);
				super.setViewPage("/WEB-INF/msg.jsp");
				
			}else {
				// 로그인 성공
				// 로그인 되어진 사용자의 정보(membervo)를 세션(session)에 저장시킨다.
				// *** 세션(session)
				// 세션(session)은 WAS(톰캣서버)의 메모리(RAM)의 일부분을 사용하는 저장공간이다.
				// 세션(session)에 저장된 데이터는 모든 파일(*.do, *.jsp)에서 
				// 사용할 수 있도록 접근이 가능하다.
				HttpSession session =  req.getSession(); // jsp 에는 바로 session 으로 사용가능하다 (내장함수)
				session.setAttribute("loginuser", membervo);
				
				
				// *** 사용자가 로그인시 아이디 저장 체크박스에 체크를 했을 경우와 체크를 해제 했을경우.
				// 쿠키저장 또는 쿠기삭제를 하도록 한다.
				// *** 쿠키(cookie) ***
				// WAS 컴퓨터가 아닌 사용자 컴퓨터의 디스크 공간을 저장공간으로 사용하는 기법을 말하며
				// 쿠키(cookie)에 저장되는 정보는 보안성이 떨어지는 데이터 이어야 한다.
				
				Cookie cookie = new Cookie("saveid", membervo.getUserid());
				// 로그인하는 사용자의 아이디값을 saveid 라는 이름의 키값으로 쿠키객체를 생성한다.
				
				if(saveid != null) {
					// 38번 라인에서 받은 것이  null 이 아닌 "on" 이라면
					cookie.setMaxAge(7*24*60*60); // 쿠키의 생존기간을 7일(단위 초)로 설정한다.
				}else {
					// 38번 라인에서 받은 것이 null 이라면
					cookie.setMaxAge(0); // 쿠키의 생존기간을 0초로 한다. 즉, 이것이 쿠키 삭제이다.
				}
				
				cookie.setPath("/");
				/*
				  	쿠키가 사용되어질 디렉토리 정보를 설정.
				  	cookie.setPath("사용되어질 경로");
				  	만일 "사용되어질 경로" 가 "/" 일 경우
				  	해당 도메인(예 iei.or.kr)의 모든 페이지에서 사용가능하다.
				 */
				
				res.addCookie(cookie);
				/*
				  	7일간 사용가능한 쿠키를 전송하든지
				  	아니면 0초짜리 사용가능한 쿠키(쿠키삭제)를
				  	사용자 컴퓨터의 웹브라우저로 쿠키를 전송시킨다.
				 */
				super.setRedirect(true); // redirect 방식으로 페이지 이동만 한다.		
				super.setViewPage("index.do");
				//	super.setViewPage(goBackURL);
				
			}

			
		}
		
	}

}
