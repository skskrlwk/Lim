package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;

public class PwdConfirmAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String method = req.getMethod();
		req.setAttribute("method", method);
		
		String userid = req.getParameter("userid");
		req.setAttribute("userid", userid);
		
		if(method.equalsIgnoreCase("post")) {
		
			String pwd = req.getParameter("pwd");
			
			MemberDAO memberdao = new MemberDAO();
			int n = 0;
			
			if(userid != null && pwd != null) {
				n = memberdao.updatePwdUser(userid, pwd);
			}
			
			req.setAttribute("n", n);
			
		}
		
		
				
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/modal/pwdConfirm.jsp");
		
	}

}
