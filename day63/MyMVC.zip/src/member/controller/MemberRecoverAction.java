package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class MemberRecoverAction extends AbstractController{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String method = req.getMethod();
		
		if(!method.equalsIgnoreCase("post")) {
			// POST 방식이 아니라면 회원복구를 하지 못하도록 한다.
			String msg = "잘못된 접근방법입니다.";
			String loc = "javascript:history.back();";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			return;
			
		}

		HttpSession session = req.getSession();
		MemberVO loginuser = (MemberVO)session.getAttribute("loginuser");
		System.out.println("확인용 >>>>>>>>>" + loginuser.getUserid());
		
		
		if(!loginuser.getUserid().equals("admin")) {
			
			String msg = "관리자가 아닙니다.";
			String loc = "javascript:history.back();";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			
			return;
			
		}
		
		String idx =req.getParameter("idx");
		String goBackURL = req.getParameter("goBackURL");
		
		MemberDAO memberdao = new MemberDAO();
		int n = memberdao.recoverMember(idx);
		
		String msg = (n>0)?"회원 복구 성공":"회원 복구 실패";
		String loc = goBackURL;
		
		req.setAttribute("msg", msg);
		req.setAttribute("loc", loc);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/msg.jsp");
	}

}
