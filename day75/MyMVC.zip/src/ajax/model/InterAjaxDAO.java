package ajax.model;

import java.sql.SQLException;
import java.util.List;

public interface InterAjaxDAO {
	
	// *** tbl_images 테이블의 모든 행을 조회하는 추상메소드 *** //
	List<ImageVO> getTblImages() throws SQLException;

	// *** tbl_ajaxnews 테이블에 입력된 데이터중 오늘 날짜에 해당하는 행만 추출(select) 하는 추상 메소드 *** //
	List<TodayNewsVO> getNewsTitleList() throws SQLException;
	
	// *** tbl_books 테이블에 있는 모든 정보를 조회하는 추상 메소드 (int num=1 전체조회  2이면 신간) *** //
	List<BookVO> getAllBooks(int num) throws SQLException;
	
	// *** jsp_wordsearchtest 테이블에  있는 검색되어진  title 컴럼값 정보를  조회해주는 추상 메소드 *** //
	List<String> getSearchWordTitle(String searchoword) throws SQLException;
	
}
