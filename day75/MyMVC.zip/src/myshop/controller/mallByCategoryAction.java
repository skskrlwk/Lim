package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import myshop.model.CategoryVO;
import myshop.model.ProductDAO;
import myshop.model.ProductVO;

public class mallByCategoryAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		super.getCategoryList(req);
		
		String code = req.getParameter("code");
		String cname = req.getParameter("cname");
		
							
		ProductDAO pdao = new ProductDAO();
		
		List<CategoryVO> categoryList = pdao.getCategoryList();
		boolean bool = true;
		
		for(CategoryVO cvo : categoryList) {
			if(cvo.getCode().equalsIgnoreCase(code)) {
				bool = false;
			}
		}
		
		if(bool) {
			super.invalidPath(req);
			return;
		}
		
		List<ProductVO> hitList = pdao.selectByPspec("HIT", code);
		
		req.setAttribute("hitList", hitList);
		req.setAttribute("cname", cname);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/malldisplay.jsp");
			
		

				
	}

}
