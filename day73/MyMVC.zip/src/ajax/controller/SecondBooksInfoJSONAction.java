package ajax.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import ajax.model.AjaxDAO;
import ajax.model.BookVO;
import ajax.model.InterAjaxDAO;
import common.controller.AbstractController;

public class SecondBooksInfoJSONAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		InterAjaxDAO adao = new AjaxDAO();
		List<BookVO> bookList = adao.getAllBooks(1);
		
		JSONArray jsonArray = new JSONArray();
		
		if(bookList != null && bookList.size() > 0) {
			
			for(BookVO vo: bookList) {
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("subject", vo.getSubject());
				jsonObj.put("title", vo.getTitle());
				jsonObj.put("registerday", vo.getRegisterday());
				jsonObj.put("author", vo.getAuthor());
			
				jsonArray.add(jsonObj);		
			}
			
		}
		
		String str_jsonArray = jsonArray.toString();
		// 값이 없으면 [] 만나온다.
		
		req.setAttribute("str_jsonArray", str_jsonArray);
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/2booksInfoJSON.jsp");
		
		
	}

}
