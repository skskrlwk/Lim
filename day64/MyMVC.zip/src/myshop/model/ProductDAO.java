package myshop.model;

import java.sql.*;
import java.util.*;

import javax.naming.*;
import javax.sql.DataSource;

public class ProductDAO implements InterProductDAO {
	
	private DataSource ds;
	// 객체변수 ds는 아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 이다. (import javax.sql.DataSource)
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	/* 
	  	=== ProductDAO 생성자에서 해야할 일은 === 
	   	아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 객체인 ds 를 빌려오는 것이다.  
	*/
	public ProductDAO() {
		try {
			Context initContext = new InitialContext(); // javax.naming 을 import한다.
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
			
		} catch (NamingException e) {
			e.printStackTrace(); 
		}
		
	}// end of ProductDAO()---------------------------------
	

	// *** 사용한 자원을 반납하는 close() 메소드 생성하기 *** //
	public void close() {
		try {
			
			if(rs != null) {
				rs.close();
				rs = null;
			}
			
			if(pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			if(conn != null) {
				conn.close();
				conn = null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}// end of close()------------------------------------


	// *** jsp_product 테이블에서 pspec 컬럼의 값(HIT, NEW, BEST) 별로 상품 목록을 가져오는 메소드 생성하기 *** // 
	@Override
	public List<ProductVO> selectByPspec(String p_spec)	throws SQLException {
		
		List<ProductVO> productList = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pspec = ? "
					+   "  order by pnum desc ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, p_spec);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;

				if(cnt==1)
					productList = new ArrayList<ProductVO>();

				int pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    ProductVO pvo = new ProductVO(pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  
			    
			    productList.add(pvo);
			    
			}// end of while-----------------
						
		} finally{
			close();
		}
				
		return productList;
	}// end of selectByPspec(String pspec)------------------------------------


	// *** jsp_product 테이블에서 pnum으로 제품1개의 정보를 받아오는 메소드 *** //
	@Override
	public ProductVO getProductOneByPnum(String pnum) throws SQLException {
		ProductVO vo = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pnum = ? ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, pnum);
			
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				int i_pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    vo = new ProductVO(i_pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  			
			}
				
		} finally{
			close();
		}
		
		
		return vo;
	}// end of getProductOneByPnum(String pnum) ---------------------------------

	
	
	
}
