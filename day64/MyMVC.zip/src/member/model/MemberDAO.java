package member.model;

import java.sql.*;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class MemberDAO implements InterMemberDAO {

	private DataSource ds;
	// 객체변수 ds는 아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 이다. (import javax.sql.DataSource)
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	/* 
	   === MemoDAO 생성자에서 해야할 일은 === 
	   아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 객체인 ds 를 빌려오는 것이다.  
	*/
	public MemberDAO() {
		try {
			Context initContext = new InitialContext(); // javax.naming 을 import한다.
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
			
		} catch (NamingException e) {
			e.printStackTrace(); 
		}
		
	}// end of MemoDAO()---------------------------------
	

	// *** 사용한 자원을 반납하는 close() 메소드 생성하기 *** //
	public void close() {
		try {
			
			if(rs != null) {
				rs.close();
				rs = null;
			}
			
			if(pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			if(conn != null) {
				conn.close();
				conn = null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}// end of close()------------------------------------
	
	// *** 중복 아이디 여부를 체크하는 메소드 *** //
	@Override
	public boolean idDuplicateCheck(String userid) throws SQLException {
	
		try {
			conn = ds.getConnection();
			String sql = "SELECT COUNT(*) AS CNT FROM jsp_member WHERE userid = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			
			rs.next();
			int cnt = rs.getInt("CNT");
			
			if(cnt == 0) { // ID중복이 아닌 경우
				return true;
			}else { // ID 중복인 경우
				return false;
			}
			
		} finally {
			close();
		}
		
		
	}// end of idDuplicateCheck(String userid)---------------------

	// *** 우편번호 찾기 메소드 *** //
	@Override
	public List<ZipcodeVO> getZipcode(String dong) throws SQLException {
		List<ZipcodeVO> zipcodeList = null;
		
		try {
			conn = ds.getConnection();
			String sql = "SELECT post1, " 
						+"  post2, " 
						+"  sido " 
						+"  || ' ' " 
						+"  || gugun " 
						+"  || ' ' " 
						+"  || dong " 
						+"  || ' ' " 
						+"  || bunji AS ADDRESS " 
						+"FROM jsp_tblpost " 
						+"WHERE dong LIKE '%' " 
						+"  || ? " 
						+"  || '%' " 
						+"ORDER BY post1, " 
						+"  post2";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dong);
			
			rs = pstmt.executeQuery();
			int cnt = 0;
			
			while(rs.next()) {
				cnt ++;
				
				if(cnt == 1) {
					zipcodeList = new ArrayList<ZipcodeVO>();
				}
				
				String post1 =rs.getString("POST1");
				String post2 = rs.getString("POST2");
				String address = rs.getString("ADDRESS");
				
				ZipcodeVO zipvo = new ZipcodeVO(post1, post2, address);
				zipcodeList.add(zipvo);
				
			}
			
		} finally {
			close();
		}
		
		return zipcodeList;
		
		
	}// end of getZipcode(String dong)-------------------------

	
	// *** 회원 가입하기 메소드 *** //
	@Override
	public int registerMember(MemberVO mvo) throws SQLException {
		
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = " insert into jsp_member(idx, name, userid, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status) "
					+ " values(seq_jsp_member.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, default, default) ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvo.getName() );
			pstmt.setString(2, mvo.getUserid());
			pstmt.setString(3, mvo.getPwd());
			pstmt.setString(4, mvo.getEmail());
			pstmt.setString(5, mvo.getHp1());
			pstmt.setString(6, mvo.getHp2());
			pstmt.setString(7, mvo.getHp3());
			pstmt.setString(8, mvo.getPost1());
			pstmt.setString(9, mvo.getPost2());
			pstmt.setString(10, mvo.getAddr1());
			pstmt.setString(11, mvo.getAddr2());
			
			result = pstmt.executeUpdate();
				
		} finally {
			close();
		}
		
		return result;
		
		
	}// end of registerMember(MemberVO mvo)-----------------------

	
	// ** 페이징처리를 안한 사용가능한(탈퇴안한사람) 전체 회원수를 알려주는 메소드 ** //
	@Override
	public List<MemberVO> getAllMember() throws SQLException {
		
		List<MemberVO> memberlist = null;
		
		try {
			conn = ds.getConnection();
			String sql = "SELECT idx, " 
						+"  userid, " 
						+"  name, " 
						+"  pwd, " 
						+"  email, " 
						+"  hp1, " 
						+"  hp2, " 
						+"  hp3, " 
						+"  post1, " 
						+"  post2, " 
						+"  addr1, " 
						+"  addr2, " 
						+"  TO_CHAR(registerday, 'yyyy-mm-dd') AS registerday, " 
						+"  status " 
						+"FROM jsp_member " 
						+"WHERE status = 1 " 
						+"ORDER BY idx DESC";

			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			
			while(rs.next()) {
				cnt++;
				
				if(cnt ==1) {
					memberlist = new ArrayList<MemberVO>();
				}
				
				int idx = rs.getInt("idx");
				String userid = rs.getString("userid");
				String name = rs.getString("name");
				String pwd = rs.getString("pwd");
				String email = rs.getString("email");
				String hp1 = rs.getString("hp1");
				String hp2 = rs.getString("hp2");
				String hp3 = rs.getString("hp3");
				String post1 = rs.getString("post1");
				String post2 = rs.getString("post2");
				String addr1 = rs.getString("addr1");
				String addr2 = rs.getString("addr2");
				String registerday = rs.getString("registerday");
				int status = rs.getInt("status");
				
				MemberVO mvo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
				
				memberlist.add(mvo);
				
			}
			
		} finally {
			close();
		}
		
		
		return memberlist;
	}// end of getAllMember()------------------------------------

	
	// ** 페이징처리를 위한 사용가능한(탈퇴안한사람) 전체 회원수를 알려주는 메소드 ** //
	@Override
	public int getTotalCount() throws SQLException {
		
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = " SELECT COUNT(*) AS cnt "
					+	 " FROM jsp_member "
						+" WHERE status = 1";

			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			result = rs.getInt("cnt");
			
		} finally {
			close();
		}
		
		
		return result;
		
	}// end of getTotalCount()-----------------------------------

	
	// *** 페이징처리를 한 전체회원을 보여주는 메소드 *** //
	@Override
	public List<MemberVO> getAllMember(int currentShowPageNo, int sizePerPage ) throws SQLException {
		
		List<MemberVO> memberlist = null;
		
		try {
			conn = ds.getConnection();
			String sql = " select RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + " from "  
					   + " ( "  
					   + "  select rownum as RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + "  from "  
					   + "  ( "  
					   + "  select idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, "  
					   + "         to_char(registerday, 'yyyy-mm-dd') as registerday, "  
					   + "         status "  
					   + "  from jsp_member "  
					   + "  where status = 1 " 
					   + "  order by idx desc "  
					   + "  )V "  
					   + " )T "  
					   + " where T.rno between ? and ? "; 
					  // 1페이지 => where T.rno between 1 and 10
					  // 2페이지 => where T.rno between 11 and 20

			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, (currentShowPageNo*sizePerPage) - (sizePerPage-1) );
			pstmt.setInt(2, (currentShowPageNo*sizePerPage) );
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			
			while(rs.next()) {
				cnt++;
				
				if(cnt ==1) {
					memberlist = new ArrayList<MemberVO>();
				}
				
				int idx = rs.getInt("idx");
				String userid = rs.getString("userid");
				String name = rs.getString("name");
				String pwd = rs.getString("pwd");
				String email = rs.getString("email");
				String hp1 = rs.getString("hp1");
				String hp2 = rs.getString("hp2");
				String hp3 = rs.getString("hp3");
				String post1 = rs.getString("post1");
				String post2 = rs.getString("post2");
				String addr1 = rs.getString("addr1");
				String addr2 = rs.getString("addr2");
				String registerday = rs.getString("registerday");
				int status = rs.getInt("status");
				
				MemberVO mvo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
				
				memberlist.add(mvo);
				
			}
			
		} finally {
			close();
		}
		
		
		return memberlist;
	
	
	}//end of getAllMember(int currentShowPageNo)----------------------------------

	
	// *** 회원 삭제(update 로 처리) 해주는 메소드 ***
	@Override
	public int deleteMember(String idx) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = "UPDATE jsp_member SET status = 0 WHERE idx = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, idx);
			
			result = pstmt.executeUpdate();
			
			
		}finally {
			close();
		}
		return result;
	}// end of deleteMember(int seq)---------------------------------

	
	// *** 회원의 정보를 알려주는  메소드 ***
	@Override
	public MemberVO getMember(String str_idx) throws SQLException {
		MemberVO vo = null;
		try {
			conn = ds.getConnection();
			String sql = "SELECT idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, " 
					+"  TO_CHAR(registerday, 'yyyy-mm-dd') AS registerday, status " 
					+"FROM jsp_member " 
					+"WHERE idx = ? ";
			
		
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, str_idx);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			int idx = rs.getInt("idx");
			String userid = rs.getString("userid");
			String name = rs.getString("name");
			String pwd = rs.getString("pwd");
			String email = rs.getString("email");
			String hp1 = rs.getString("hp1");
			String hp2 = rs.getString("hp2");
			String hp3 = rs.getString("hp3");
			String post1 = rs.getString("post1");
			String post2 = rs.getString("post2");
			String addr1 = rs.getString("addr1");
			String addr2 = rs.getString("addr2");
			String registerday = rs.getString("registerday");
			int status = rs.getInt("status");
			
			vo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
		
		} finally {
			close();
		}
		
		return vo;
		
	}// end of getMember(String str_idx)--------------------------------------

	// *** 회원의 정보를 수정해주는  메소드 ***
	@Override
	public int updateMember(MemberVO mvo) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = " update jsp_member set name = ?, pwd = ?, email = ?, hp1 = ?, hp2 = ?, hp3 = ?, post1 = ?, post2 = ?, addr1 = ?, addr2 = ? "
					+ " where idx=? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mvo.getName());
			pstmt.setString(2, mvo.getPwd());
			pstmt.setString(3, mvo.getEmail());
			pstmt.setString(4, mvo.getHp1());
			pstmt.setString(5, mvo.getHp2());
			pstmt.setString(6, mvo.getHp3());
			pstmt.setString(7, mvo.getPost1());
			pstmt.setString(8, mvo.getPost2());
			pstmt.setString(9, mvo.getAddr1());
			pstmt.setString(10, mvo.getAddr2());
			pstmt.setInt(11, mvo.getIdx());
			
			result = pstmt.executeUpdate();
			
		} finally {
			close();
			
		}
		return result;
		
		
	}// end of updateMember(MemberVO mvo)---------------------------
	
	
	
	// *** (일반 사용자용)검색된 정보를 알려주는 추상 메소드 ***//
	@Override
	public List<MemberVO> getSearchMember(String selectVal, String searchText, String selDate, int currentShowPageNo, int sizePerPage) throws SQLException {
		
		
		List<MemberVO> voList = null;
		try {
			conn = ds.getConnection();
			/*
			  String sql = "SELECT idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, " 
					  +"  TO_CHAR(registerday, 'yyyy-mm-dd') AS registerday, status " 
					  +"  FROM jsp_member " 
					  +"  WHERE "+ selectVal + " like '%' || ? || '%' ";
			*/
			
			String sql =" select RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + " from "  
					   + " ( "  
					   + "  select rownum as RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + "  from "  
					   + "  ( "  
					   + "  select idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, "  
					   + "         to_char(registerday, 'yyyy-mm-dd') as registerday, " 
					   + "         status "  
					   + "  from jsp_member "  
					   + "  WHERE status = 1 and "+ selectVal + " like '%' || ? || '%' ";
			
					   switch (selDate) {
								
							case "3":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 3 ";
								break;
								
							case "10":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 10 ";
								break;
								
							case "30":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 30 ";
								break;
							case "60":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 60 ";
								break;
								
							default:
								break;
					   }
					   
				   sql += "  order by idx desc "  
					   + "  )V "  
					   + " )T "  
					   + " where T.rno between ? and ? ";
					   
					   
					   
					    
					  // 1페이지 => where T.rno between 1 and 10
					  // 2페이지 => where T.rno between 11 and 20
			
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchText);
			pstmt.setInt(2, (currentShowPageNo*sizePerPage) - (sizePerPage-1) );
			pstmt.setInt(3, (currentShowPageNo*sizePerPage) );
			rs = pstmt.executeQuery();		
			
			int cnt = 0;
			
			while(rs.next()) {
				
				cnt++;
				if(cnt == 1) {
					voList = new ArrayList<MemberVO>();
				}
				
				int idx = rs.getInt("idx");
				String userid = rs.getString("userid");
				String name = rs.getString("name");
				String pwd = rs.getString("pwd");
				String email = rs.getString("email");
				String hp1 = rs.getString("hp1");
				String hp2 = rs.getString("hp2");
				String hp3 = rs.getString("hp3");
				String post1 = rs.getString("post1");
				String post2 = rs.getString("post2");
				String addr1 = rs.getString("addr1");
				String addr2 = rs.getString("addr2");
				String registerday = rs.getString("registerday");
				int status = rs.getInt("status");
				
				MemberVO vo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
				
				voList.add(vo);
				
			}
		} finally {
			close();
		}
		
		
		return voList;
	}// end of getSearchMember(String selectVal, String searchText, String selDate, int currentShowPageNo, int sizePerPage)  -------------------------

	
	// *** 검색된 회원의 명수를 알려주는 추상 메소드 
	@Override
	public int getCountMember(String selectVal, String searchText, String selDate) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			
			String sql = " SELECT count(*) as cnt "
					   +"  FROM jsp_member " 
					   +"  WHERE status = 1 and " + selectVal + " like '%' || ? || '%'";
			
			switch (selDate) {
				case "3":
					sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 3 ";
					break;
					
				case "10":
					sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 10 ";
					break;
					
				case "30":
					sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 30 ";
					break;
					
				case "60":
					sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 60 ";
					break;	
					
				default:
					break;
			}
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchText);
			rs = pstmt.executeQuery();
			
			rs.next();
			result = rs.getInt("cnt");
			// System.out.println("result 확인값 : "+result);
			
			
			
		} finally {
			close();
		}
		return result;
		
	}// end of getCountMember(String selectVal, String searchText)--------------------------


	// ** 로그인 처리(로그인 성공: 회원정보를 리턴, 로그인이 실패: null 리턴) 해주는 메소드 ** //
	@Override
	public MemberVO loginOKmemberInfo(String userid, String pwd) throws SQLException {
		
		MemberVO membervo = null;
		try {
			conn = ds.getConnection();
			
			String sql = " select idx, userid, name, pwd, email, hp1, hp2, hp3, "
						+" post1, post2, addr1, addr2, "
						+" to_char(registerday, 'yyyy-mm-dd') as registerday, "
						+" status, gender, birthday "
						+" from jsp_member "
						+" where status = 1 and userid = ? and pwd = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, pwd);
			
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				
				int idx = rs.getInt("idx");
				String str_userid = rs.getString("userid");
				String name = rs.getString("name");
				String str_pwd = rs.getString("pwd");
				String email = rs.getString("email");
				String hp1 = rs.getString("hp1");
				String hp2 = rs.getString("hp2");
				String hp3 = rs.getString("hp3");
				String post1 = rs.getString("post1");
				String post2 = rs.getString("post2");
				String addr1 = rs.getString("addr1");
				String addr2 = rs.getString("addr2");
				String registerday = rs.getString("registerday");
				int status = rs.getInt("status");
				String gender = rs.getString("gender");
				String birthday = rs.getString("birthday");
				
				membervo = new MemberVO(idx, str_userid, name, str_pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status, gender, birthday);
			}
			
		}finally {
			close();
		}
		
		return membervo;
	}// end of loginOKmemberInfo(String userid, String pwd) ---------------------------------------


	@Override
	public List<MemberVO> getSearchMemberWithDel(String selectVal, String searchText, String selDate,
			int currentShowPageNo, int sizePerPage) throws SQLException {

		List<MemberVO> voList = null;
		try {
			conn = ds.getConnection();
			/*
			  String sql = "SELECT idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, " 
					  +"  TO_CHAR(registerday, 'yyyy-mm-dd') AS registerday, status " 
					  +"  FROM jsp_member " 
					  +"  WHERE "+ selectVal + " like '%' || ? || '%' ";
			*/
			
			String sql =" select RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + " from "  
					   + " ( "  
					   + "  select rownum as RNO ,idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status "  
					   + "  from "  
					   + "  ( "  
					   + "  select idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, "  
					   + "         to_char(registerday, 'yyyy-mm-dd') as registerday, " 
					   + "         status "  
					   + "  from jsp_member "  
					   + "  WHERE "+ selectVal + " like '%' || ? || '%' ";
			
					   switch (selDate) {
								
							case "3":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 3 ";
								break;
								
							case "10":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 10 ";
								break;
								
							case "30":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 30 ";
								break;
							case "60":
								sql += " and to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday,'yyyy-mm-dd'), 'yyyy-mm-dd') <= 60 ";
								break;
								
							default:
								break;
					   }
					   
				   sql += "  order by idx desc "  
					   + "  )V "  
					   + " )T "  
					   + " where T.rno between ? and ? ";
					   
					   
					   
					    
					  // 1페이지 => where T.rno between 1 and 10
					  // 2페이지 => where T.rno between 11 and 20
			
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, searchText);
			pstmt.setInt(2, (currentShowPageNo*sizePerPage) - (sizePerPage-1) );
			pstmt.setInt(3, (currentShowPageNo*sizePerPage) );
			rs = pstmt.executeQuery();		
			
			int cnt = 0;
			
			while(rs.next()) {
				
				cnt++;
				if(cnt == 1) {
					voList = new ArrayList<MemberVO>();
				}
				
				int idx = rs.getInt("idx");
				String userid = rs.getString("userid");
				String name = rs.getString("name");
				String pwd = rs.getString("pwd");
				String email = rs.getString("email");
				String hp1 = rs.getString("hp1");
				String hp2 = rs.getString("hp2");
				String hp3 = rs.getString("hp3");
				String post1 = rs.getString("post1");
				String post2 = rs.getString("post2");
				String addr1 = rs.getString("addr1");
				String addr2 = rs.getString("addr2");
				String registerday = rs.getString("registerday");
				int status = rs.getInt("status");
				
				MemberVO vo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
				
				voList.add(vo);
				
			}
		} finally {
			close();
		}
		return voList;
		
	}// end of getSearchMemberWithDel(String selectVal, String searchText, String selDate, int currentShowPageNo, int sizePerPage) --------


	// *** 삭제된 회원을 복구(update 처리)해주는 메소드 *** //
	@Override
	public int recoverMember(String idx) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			
			String sql = " update jsp_member set status = 1 "
						+" where idx = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, idx);
			result = pstmt.executeUpdate();		
			
		} finally {
			close();
			
		}
		
		return result;
	}// end of recoverMember(String idx) -------------------------------


	// *** ID찾기를 해주는 메소드 ***//
	@Override
	public String getUserid(String name, String mobile) throws SQLException {
		String result = null;
		try {
			conn = ds.getConnection();
			
			String sql = " select userid "
						+" from jsp_member "
						+" where status = 1 and "
						+" name = ? and "
						+" trim(hp1) || trim(hp2) || trim(hp3) = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, mobile);
			
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				result = rs.getString("userid");
			}
			
		}finally {
			close();
		}
		
		return result;
	}// end of getUserid(String name, String mobile) -------------------------------


	// *** 비밀번호 찾기를 위해 먼저 userid 와 email을 가지는 사용자가 존재하는지 검증해주는 메소드 *** //
	@Override
	public int isUserExists(String userid, String email) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			
			String sql = " select count(*) AS CNT "
						+" from jsp_member "
						+" where status = 1 and "
						+" 		 userid = ? and "
						+" 		 email = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, email);
			
			rs = pstmt.executeQuery();
			rs.next();
			
			result = rs.getInt("CNT");
			
		} finally {
			close();
		}
		
		return result;
	}// end of isUserExists(String userid, String email) -----------------------------


	// *** 암호를 새암호로 변경하는 추상 메소드 *** //
	@Override
	public int updatePwdUser(String userid, String pwd) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			
			String sql = " update jsp_member set pwd = ? "
						+" where userid = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pwd);
			pstmt.setString(2, userid);
			
			result = pstmt.executeUpdate();
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of updatePwdUser(String userid, String pwd) -----------------------------------

	
	

}
