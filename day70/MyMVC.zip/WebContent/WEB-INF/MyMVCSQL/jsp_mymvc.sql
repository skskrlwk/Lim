-------------- *** JSP & Servlet *** ---------------

-------------- *** MyMVC *** ------------------

show user;
-- USER��(��) "MYORAUSER"�Դϴ�.

--- 1. ���� �޸��� ---
create table jsp_memo
(idx number(8) not null, -- �۹�ȣ(�������� �Է�)
 userid varchar2(20) not null, -- ȸ�� ���̵�
 name varchar2(20) not null, -- �ۼ��� �̸� 
 msg varchar2(100), -- �޸𳻿�
 writedate date default sysdate, -- �ۼ�����
 cip varchar2(20), -- Ŭ���̾�Ʈ IP �ּ�
 status number(1) default 1 not null, -- �ۻ��� ���� 
 constraint PK_jsp_memo_idx primary key(idx),
 constraint FK_jsp_memo_userid foreign key(userid)
                                references jsp_member(userid),
 constraint CK_jsp_memo_status check(status in(0,1))                                
);

create sequence jsp_memo_idx
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;

select *
from jsp_memo
order by idx desc;


select *
from jsp_member
order by idx desc;

select A.idx, A.msg, to_char(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
       A.cip, B.name, B.email
from jsp_memo A join jsp_member B
on A.userid = B.userid
where A.status = 1
order by idx desc;


+"SELECT A.idx, " 
+"  A.msg, " 
+"  TO_CHAR(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate, " 
+"  A.cip, " 
+"  B.name " 
+"FROM jsp_memo A " 
+"JOIN jsp_member B " 
+"ON A.userid    = B.userid " 
+"WHERE A.status = 1 " 
+"ORDER BY idx DESC;"


------ *** ���� �÷��߰� *** ------ 
alter table jsp_member  -- ���� : 1 / ���� : 2
add gender char(1);

-- *** ������� �÷� �߰� *** --
alter table jsp_member
add birthday varchar2(8);

-------------------------------------------------------
update jsp_member set gender = '2'
where name like '%��ȭ%' or name like '%����%';

update jsp_member set gender = '1'
where not (name like '%��ȭ%' or name like '%����%');

commit;

update jsp_member set birthday = '19850420'
where idx between 1 and 30;

update jsp_member set birthday = '19900825'
where idx between 31 and 60;

update jsp_member set birthday = '19931001'
where idx between 61 and 90;

update jsp_member set birthday = '19950515'
where idx between 91 and 120;

update jsp_member set birthday = '19970925'
where idx between 121 and 150;

update jsp_member set birthday = '20010220'
where idx between 151 and 180;

update jsp_member set birthday = '20021210'
where idx between 181 and 210;

commit;update jsp_member set birthday = '19850420'
where idx between 1 and 30;

commit;

select *
from jsp_member
order by idx desc;

select A.idx, A.msg, to_char(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
       A.cip, B.name, B.email, B.gender,
      ( extract(year from sysdate)  - to_number(substr(B.birthday,1,4)) ) + 1 AS age
from jsp_memo A join jsp_member B
on A.userid = B.userid
where A.status = 1
order by idx desc;

declare 
  v_cnt number(3) := 1;

begin
  loop 
    insert into jsp_memo(idx, userid, name, msg, writedate, cip, status)
    values(jsp_memo_idx.nextval, 'leess', '�̼���', v_cnt || '�ȳ��ϼ���? �̼����Դϴ�.', default, '127.0.0.1', default);
    v_cnt := v_cnt + 1;
  exit when v_cnt > 100;
  end loop;
end;

select *
from jsp_memo;

commit;

SELECT idx, msg, writedate, cip, name, email, gender, age, status
FROM
(
  SELECT rownum AS RNO, idx, msg, writedate,
          cip, name, email, gender, age, status
  From
  (
    SELECT A.idx, A.msg, 
           TO_CHAR(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
           A.cip, B.name,	 B.email,  B.gender, A.status,
           extract(year from sysdate) - to_number(substr(B.birthday,1,4)) + 1 AS age 
    FROM jsp_memo A JOIN jsp_member B  
    ON A.userid = B.userid 
    WHERE A.status = 1 
    ORDER BY idx DESC
  )V
)T
WHERE t.rno between 1 and 10


select *
from jsp_memo
order by 1 desc;

select *
from jsp_member
order by 1 desc;


select idx, userid, name, pwd, email, hp1, hp2, hp3, addr1, addr2, registerday, status, gender, birthday
from jsp_member

select count(*) AS CNT
from jsp_member
where userid = 'leess'


select *
from jsp_member
order by 1 desc;


select idx, userid, name, pwd, email, hp1, hp2, hp3,
       post1, post2, addr1, addr2,
       to_char(registerday, 'yyyy-mm-dd') as registerday,
       status, gender, birthday
from jsp_member
where status = 1 and userid = 'leess' and pwd = 'qwer1234$'

select userid
from jsp_member 
where status = 1 and 
name = ? and 
trim(hp1) || trim(hp2) || trim(hp3) = 01011111111;


update jsp_member set email='rbgk5868@naver.com'
where userid = 'test1'
commit;

------------------------------------------------------------------------------
                      --- *** ���θ� *** ---
/*
   ī�װ��� ���̺��� : jsp_category

   �÷����� 
     -- ī�װ��� ��з� ��ȣ  : ������(seq_jsp_category_cnum)�� ������.(Primary Key)
     -- ī�װ��� �ڵ�(unique) : ex) ������ǰ  '100000'
                                   �Ƿ�     '200000'
                                   ����     '300000' 
     -- ī�װ�����(not null)  : ������ǰ, �Ƿ�, ����           
  
*/ 
 
create table jsp_category
(cnum    number(8)     not null  -- ī�װ��� ��з� ��ȣ
,code    varchar2(20)  not null  -- ī�װ��� �ڵ�
,cname   varchar2(100) not null  -- ī�װ�����
,constraint PK_jsp_category_cnum primary key(cnum)
,constraint UQ_jsp_category_code unique(code)
);

create sequence seq_jsp_category_cnum
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;

insert into jsp_category values(seq_jsp_category_cnum.nextval, '100000', '������ǰ');
insert into jsp_category values(seq_jsp_category_cnum.nextval, '200000', '�Ƿ�');
insert into jsp_category values(seq_jsp_category_cnum.nextval, '300000', '����');

commit;

select *
from jsp_category;


---- *** ��ǰ ���̺� : jsp_product *** ----
create table jsp_product
(pnum           number(8) not null       -- ��ǰ��ȣ(Primary Key)
,pname          varchar2(100) not null   -- ��ǰ��
,pcategory_fk   varchar2(20)             -- ī�װ����ڵ�(Foreign Key)
,pcompany       varchar2(50)             -- ����ȸ���
,pimage1        varchar2(100) default 'noimage.png' -- ��ǰ�̹���1   �̹������ϸ�
,pimage2        varchar2(100) default 'noimage.png' -- ��ǰ�̹���2   �̹������ϸ� 
,pqty           number(8) default 0      -- ��ǰ �����
,price          number(8) default 0      -- ��ǰ ����
,saleprice      number(8) default 0      -- ��ǰ �ǸŰ�(�����ؼ� �� ���̹Ƿ�)
,pspec          varchar2(20)             -- 'HIT', 'BEST', 'NEW' ���� ���� ����.
,pcontent       clob                     -- ��ǰ����  varchar2�� varchar2(4000) �ִ밪�̹Ƿ�
                                         --          4000 byte �� �ʰ��ϴ� ��� clob �� ����Ѵ�.
                                         --          clob �� �ִ� 4GB ���� �����Ѵ�.
                                         
,point          number(8) default 0      -- ����Ʈ ����                                         
,pinputdate     date default sysdate     -- ��ǰ�԰�����
,constraint  PK_jsp_product_pnum primary key(pnum)
,constraint  FK_jsp_product_pcategory_fk foreign key(pcategory_fk)
                                         references jsp_category(code)
);

create sequence seq_jsp_product_pnum
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;

insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '����ƮTV', '100000', '�Ｚ',
       'tv_samsung_h450_1.png','tv_samsung_h450_2.png',
       100,1200000,800000,'HIT','42��ġ ����Ʈ TV. ��� ¯!!', 50);


insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '��Ʈ��', '100000', '����',
       'notebook_lg_gt50k_1.png','notebook_lg_gt50k_2.png',
       150,900000,750000,'HIT','��Ʈ��. ��� ¯!!', 30);  
       

insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '����', '200000', 'S��',
       'cloth_canmart_1.png','cloth_canmart_2.png',
       20,12000,10000,'HIT','������!!', 5);       
       

insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '����', '200000', '��ī��',
       'cloth_buckaroo_1.png','cloth_buckaroo_2.png',
       50,15000,13000,'HIT','������!!', 10);       
       

insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '����Ž�躸��ã��ø���', '300000', '���̼���',
       'book_bomul_1.png','book_bomul_2.png',
       100,35000,33000,'HIT','��ȭ�� ���� ���迩��', 20);       
       
       
insert into jsp_product(pnum, pname, pcategory_fk, pcompany, 
                        pimage1, pimage2, pqty, price, saleprice,
                        pspec, pcontent, point)
values(seq_jsp_product_pnum.nextval, '��ȭ�ѱ���', '300000', '���������',
       'book_koreahistory_1.png','book_koreahistory_2.png',
       80,130000,120000,'HIT','��ȭ�� ���� �̾߱� �ѱ��� ����', 60);
       
commit;       

select *
from jsp_product; 

update jsp_product set pspec = 'HIT';
commit;

-------------- *** ��ٱ��� ���̺� �����ϱ� *** -------------------
desc jsp_member;
desc jsp_product;

create table jsp_cart
(cartno number            not null,   -- ��ٱ��� ��ȣ
 userid varchar2(20)      not null,   -- ����� ID
 pnum number(8)           not null,   -- ��ǰ��ȣ
 oqty number(8) default 0 not null,   -- �ֹ��� 
 status number(1) default 1,          -- ��������
 constraint PK_jsp_cart_cartno primary key(cartno),
 constraint FK_jsp_cart_userid foreign key(userid)
                               references jsp_member(userid),
 constraint FK_jsp_cart_pnum foreign key(pnum)
                             references jsp_product(pnum),
 constraint CK_jsp_cart_status check( status in(0,1) )                            
 );
 
 create sequence seq_jsp_cart_cartno
 start with 1
 increment by 1
 nomaxvalue
 nominvalue
 nocycle
 nocache;


----- �ڸ�Ʈ �ޱ� -------
comment on table jsp_cart
is '��ٱ��� ���̺�';

comment on column jsp_cart.cartno
is '��ٱ��Ϲ�ȣ(�������� : seq_jsp_cart_cartno)';

comment on column jsp_cart.userid
is 'ȸ��ID jsp_member ���̺��� userid �÷��� �����Ѵ�.';

comment on column jsp_cart.pnum
is '��ǰ��ȣ jsp_product ���̺��� pnum �÷��� �����Ѵ�.';

comment on column jsp_cart.oqty
is '��ٱ��Ͽ� ���� ��ǰ�� �ֹ���';

comment on column jsp_cart.status
is '��ٱ��Ͽ� ����� ������ 1, ��ٱ��Ͽ��� ���� 0';
 
---- �ڸ�Ʈ Ȯ�� ----- 
select *
from user_tab_comments; 


select column_name,comments
from user_col_comments
where table_name = 'JSP_CART';

select *
from jsp_cart


insert into jsp_cart(cartno, userid, pnum, oqty)
values(seq_jsp_cart_cartno.nextval, ?, ?, ?)

update jsp_cart set status = 0
where cartno = 1

select B.cartno, B.userid, B.pnum,
       A.pname, A.pcategory_fk, A.pimage1, 
       A.price, A.saleprice, B.oqty, A.point, B.status
from jsp_product A join jsp_cart B
on A.pnum = B.pnum
where B.userid = 'test1' and
      B.status = 1


select count(*) AS CNT
from jsp_cart
where status = 1 and  
      userid = 'test1'; 

select cartno, userid , pnum, pname, pcategory_fk, pimage1, price, saleprice, oqty, point, status
from
(   
  select rownum AS RNO, cartno, userid , pnum, pname,
         pcategory_fk, pimage1, price, saleprice, oqty, point, status
  from
  (
    select B.cartno, B.userid, B.pnum,
           A.pname, A.pcategory_fk, A.pimage1, 
           A.price, A.saleprice, B.oqty, A.point, B.status
    from jsp_product A join jsp_cart B
    on A.pnum = B.pnum
    where B.userid = 'test1' and B.status = 1 
   )V    
)T      
where rno between 1 and 2


---- jsp-member ���̺��� �÷� coin, point �߰��ϱ� -------------

alter table jsp_member
add coin number default 0 not null;

alter table jsp_member
add point number default 0 not null;

update jsp_member set coin = 90000000
where userid = 'test1';

update jsp_member set coin = 10000
where userid = 'leess';

commit;

select *
from jsp_member
order by 1 desc;




---- >>> �ϳ��� ��ǰ�ӿ� �������� �̹��� ���� �־��ֱ� ------------

select *
from jsp_product
order by pnum asc;


create table jsp_product_imagefile
(imgfileno number not null,            -- �������� �Է¹���.
 fk_pnum number(8) not null,           -- ��ǰ��ȣ(foreign key)
 imgfilename varchar2(100) not null,   -- ��ǰ �̹��� ���ϸ�
 constraint PK_jsp_product_imagefile primary key(imgfileno),
 constraint FK_jsp_product_imagefile foreign key(fk_pnum)
                                     references jsp_product(pnum)
);

create sequence seq_imgfileno
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;

insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename)
values(seq_imgfileno.nextval, 3, 'cloth_canmart_3.png');

insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename)
values(seq_imgfileno.nextval, 3, 'cloth_canmart_4.png');

insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename)
values(seq_imgfileno.nextval, 3, 'cloth_buckaroo_3.png');

insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename)
values(seq_imgfileno.nextval, 3, 'cloth_buckaroo_4.png');

insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename)
values(seq_imgfileno.nextval, 3, 'cloth_buckaroo_5.png');

commit;

select imgfileno, fk_pnum, imgfilename
from jsp_product_imagefile
order by imgfileno;

select imgfileno, fk_pnum, imgfilename
from jsp_product_imagefile
where fk_pnum = 4
order by imgfileno desc;


select *
from jsp_product;



-------- >>> �ֹ����� ���̺� <<< ----------
-- [1] �ֹ����� ���̺� : jsp_order
-- [2] �ֹ� �� ���̺� : jsp_order_detail

-- *** "�ֹ� ����" ���̺� *** --

create table jsp_order
(odrcode varchar2(20)   not null,        -- �ֹ��ڵ�(��������ȣ)  �ֹ��ڵ� ���� : kh+��¥+sequence =  kh20180430-1, kh20180430-2, kh20180501-1 ...
 fk_userid varchar2(20) not null,        -- ����� ID
 odrtotalPrice number   not null,        -- �ֹ��Ѿ�
 odrtotalPoint number not null,                 -- �ֹ�������Ʈ
 odrdate date default sysdate not null,  -- �ֹ�����
 constraint PK_jsp_order_odrcode primary key(odrcode),
 constraint FK_jsp_order_fk_userid foreign key(fk_userid)
                                   references jsp_member(userid) 
);

-- "�ֹ��ڵ�(��������ȣ) ������" ����
create sequence seq_jsp_order
start with 1
increment by 1
nominvalue
nomaxvalue
nocycle
nocache;

select odrcode, fk_userid,
       odrtotalPrice, odrtotalPoint,
       to_char(odrdate, 'yyyy-mm-dd hh24:mi:ss') AS odrdate
from jsp_order
order by odrcode desc;



-- *** "�ֹ� �� ���̺� " *** --
create table jsp_order_detail
(odrseqnum number not null,                  -- �ֹ��� �Ϸù�ȣ
 fk_odrcode varchar2(20) not null,           -- �ֹ��ڵ�(��������ȣ)
 fk_pnum number(8) not null ,                -- ��ǰ��ȣ
 oqty number not null,                       -- �ֹ���
 odrprice number not null,                   -- �ֹ��� ����� ���� �Ǹ� ���� ==> insert �� jsp_product ���̺����� �ش���ǰ�� saleprice �÷����� �о�ٰ� �־��־�� �Ѵ�.
 deliverStatus number(1) default 1 not null, -- ��ۻ���( 1 : �ֹ��� ����. 2 : ��۽���, 3 : ��ۿϷ�)
 deliverDate date,                           -- ��ۿϷ� default �� null�� ��.
 constraint PK_jsp_order_detail_odrseqnum primary key(odrseqnum),
 constraint FK_jsp_order_detail_fk_odrcode foreign key(fk_odrcode)
                                           references jsp_order(odrcode) on delete cascade,
 constraint FK_jsp_order_detail_fk_pnum foreign key(fk_pnum)
                                           references jsp_product(pnum),
 constraint CK_jsp_order_detail check(deliverStatus in(1,2,3))                                          
 );
 
 -- "�ֹ��ڵ�(��������ȣ) ������" ����
create sequence seq_jsp_order_detail
start with 1
increment by 1
nominvalue
nomaxvalue
nocycle
nocache;

select odrseqnum, fk_odrcode, fk_pnum, oqty,
       odrprice, deliverStatus,
       to_char(deliverDate, 'yyyy-mm-dd hh24:mi:ss') AS deliverDate
from jsp_order_detail
order by odrseqnum desc;

select *
from jsp_product;

select *
from jsp_member
order by 1 desc;

select *
from jsp_product 
where pnum in(1,3,5,6);

desc jsp_product


select *
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode;

select odrseqnum, fk_odrcode, fk_pnum, oqty,
       odrprice, deliverStatus,
       to_char(deliverDate, 'yyyy-mm-dd hh24:mi:ss') AS deliverDate
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode
where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd')
      and fk_userid = 'test1'
order by odrseqnum desc;

select count(*) as cnt
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode
where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd')
      and fk_userid = 'test1'
order by odrseqnum desc;




select *
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode
join jsp_product C 
on A.fk_pnum = C.pnum
where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd')
      and fk_userid = 'test1'
order by odrseqnum desc;


select rno, odrcode, oqty, odrprice, deliverstatus,
       odrtotalprice, odrtotalpoint, odrdate,
       pnum, pname, pimage1, price, point
from
(
  select rownum as rno, odrcode, oqty, odrprice, deliverstatus,
         odrtotalprice, odrtotalpoint, odrdate,
         pnum, pname, pimage1, price, point
  from 
  (
    select odrcode, oqty, odrprice, deliverstatus,
           odrtotalprice, odrtotalpoint, to_char(odrdate,'yyyy-mm-dd') as odrdate,
           pnum, pname, pimage1, price, point
    from jsp_order_detail A join jsp_order B
    on A.fk_odrcode = B.odrcode
    join jsp_product C 
    on A.fk_pnum = C.pnum
    where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd')
          and fk_userid = 'test1'
    order by odrseqnum desc
  )V
)T
where rno between 1 and 3;


select *
from jsp_order_detail;

select *
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode
join jsp_member C on B.fk_userid = C.userid
where odrcode = 'kh20180502-1';

select idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2,
       TO_CHAR(registerday, 'yyyy-mm-dd') AS registerday,status, coin,  point
from jsp_order_detail A join jsp_order B
on A.fk_odrcode = B.odrcode
join jsp_member C on B.fk_userid = C.userid
where odrcode = 'kh20180502-1';


select *
from jsp_order_detail;

select odrseqnum, fk_odrcode || fk_pnum, odrprice, deliverstatus, deliverdate
from jsp_order_detail; -- fk_odrcode || fk_pnum �÷��� �Ѱ��� ��ģ��.

update jsp_order_detail set deliverstatus = 2
where fk_odrcode || fk_pnum in ('kh20180502-112','kh20180502-113');
			
rollback;





