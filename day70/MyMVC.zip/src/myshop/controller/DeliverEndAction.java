package myshop.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.InterProductDAO;
import myshop.model.ProductDAO;

public class DeliverEndAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		String method = req.getMethod();
		
		if(!method.equalsIgnoreCase("post")) {
			super.invalidPath(req);
			return;
		}
		
		MemberVO loginuser = super.getMemberLogin(req);
		
		if (loginuser == null) {	
			return;
		} 
		else if(!"admin".equals(loginuser.getUserid())) {
			super.alertMsg(req, "관리자만 가능합니다.", "javascript:history.back();");
			return;
		}
		
		String[] odrcodeArr = req.getParameterValues("odrcode");
		String[] pnumArr = req.getParameterValues("deliverEndPnum");	
		
		StringBuffer sbf = new StringBuffer();
		
		for(int i=0; i<odrcodeArr.length; i++) {
			sbf.append("\'"+odrcodeArr[i]+pnumArr[i]+"\',");
			// 'kh20180502-112', 'kh20180502-113'
		}
		
		String odrcodePnum = sbf.toString();
		odrcodePnum = odrcodePnum.substring(0, odrcodePnum.length()-1); // 마지막 , 제거하기
		
		InterProductDAO pdao = new ProductDAO();
		int n = pdao.updateDeliverEnd(odrcodePnum, odrcodeArr.length);
		
		if(n == 1) {
			super.alertMsg(req, "선택하신 제품들은 배송 완료로 변경되었습니다.", "orderList.do");
		} 
		else {
			super.alertMsg(req, "변경이 실패하였습니다.", "javascript:history.back();");
		}
		
		
	}
 
}
