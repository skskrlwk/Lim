package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class MemberEditAction extends AbstractController{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		HttpSession ses = req.getSession();
		MemberVO loginuser = (MemberVO)ses.getAttribute("loginuser"); 
		
		if(loginuser == null) {
			String msg = "비정상적인 경로로 들어왔습니다.";
		    String loc = "javascript:history.back();";
		    
		    req.setAttribute("msg", msg);
		    req.setAttribute("loc", loc);
		    
		    super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
		    
			return;
		}
		else if(loginuser != null && !"admin".equals(loginuser.getUserid()) ) {
			String msg = "관리자가 아닙니다.";
		    String loc = "javascript:history.back();";
		    
		    req.setAttribute("msg", msg);
		    req.setAttribute("loc", loc);
		    
		    super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
		    
			return;
		}
		else if (loginuser != null && "admin".equals(loginuser.getUserid())) {
		
			MemberDAO memberDao = new MemberDAO();
		
			String str_idx = req.getParameter("idx");
			String goBackURL = req.getParameter("goBackURL");
				
			MemberVO mvo = null;
			int idx = 0;
			try{
			    idx = Integer.parseInt(str_idx);
			    	
			   	if(idx < 1) {
		    	
			   		String msg = "비정상적인 경로로 들어왔습니다.";
				    String loc = "javascript:history.back();";
				    
				    req.setAttribute("msg", msg);
				    req.setAttribute("loc", loc);
				    
				    super.setRedirect(false);
				    super.setViewPage("/WEB-INF/msg.jsp");
				    
				    return;
		    	}
			    else {
			    		mvo = memberDao.getMember(String.valueOf(idx));
			    	    req.setAttribute("mvo", mvo);
			    	    req.setAttribute("goBackURL", goBackURL);
			    	    			    	    
			    	    super.setRedirect(false);
			    	    super.setViewPage("/WEB-INF/member/memberEdit.jsp");
						
						return;
			    	}
			   	
			    } catch(NumberFormatException e) {
			   	
			    	String msg = "비정상적인 경로로 들어왔습니다.";
				    String loc = "javascript:history.back();";
				    
				    req.setAttribute("msg", msg);
				    req.setAttribute("loc", loc);
				    
				    super.setRedirect(false);
				    super.setViewPage("/WEB-INF/msg.jsp");
				    
				    return;
			    }
			
		}// end of else~if-----------------
		
	}

}
