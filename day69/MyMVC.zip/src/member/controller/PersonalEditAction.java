package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class PersonalEditAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		HttpSession session = req.getSession();
		MemberVO loginuser = (MemberVO)session.getAttribute("loginuser");
		String str_idx = req.getParameter("idx");
		
		if(loginuser == null || ( loginuser != null && !String.valueOf(loginuser.getIdx()).equals(str_idx)) ) {
			// 로그인을 하지 않은 상태에서는 볼수가 없도록 해야 한다.
			// 로그인을 했지만 다른 사용자의 정보는 변경이 불가하도록 해야한다.
			
			String msg = "비정삭적인 경로로 들어왔습니다.";
			String loc = "javascript:history.back();";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			return;
			
		}else if (loginuser != null || ( loginuser != null && String.valueOf(loginuser.getIdx()).equals(str_idx))) {
			
			MemberDAO memberdao = new MemberDAO();
			MemberVO mvo = memberdao.getMember(str_idx);
			
			req.setAttribute("mvo", mvo);
			req.setAttribute("str_idx", str_idx);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/member/memberEdit.jsp");			
		}
		
	
		
	
		
	}

}
