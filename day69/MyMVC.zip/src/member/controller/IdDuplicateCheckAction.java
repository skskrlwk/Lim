package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import memo.model.MemoDAO;

public class IdDuplicateCheckAction extends AbstractController{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
				
		MemberDAO memberdao = new MemberDAO();
		String userid = req.getParameter("userid");
		int check = 0;
		
		if(userid == null) {
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/member/idDuplicateCheck.jsp");
			
		}else {
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>" + userid);
			boolean bool = memberdao.idDuplicateCheck(userid);
						
			if(bool) {
				// 사용 가능한 아이디
				check = 1;
				
			}
			
			req.setAttribute("userid", userid);
			req.setAttribute("check", check);
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/member/idDuplicateCheck.jsp");
			
		}
		
		
		
		
		
	}

}
