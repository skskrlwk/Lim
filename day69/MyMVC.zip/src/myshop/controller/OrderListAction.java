package myshop.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.CartVO;
import myshop.model.ProductDAO;
import util.my.MyUtil;

public class OrderListAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		super.getCategoryList(req);
		MemberVO loginuser = super.getMemberLogin(req);
		ProductDAO pdao = new ProductDAO();
		
		if(loginuser == null) {
			return;
		}
		
		String str_sizePerPage = req.getParameter("sizePerPage");
		System.out.println("str_sizePerPage >>>>>>>>>" + str_sizePerPage);
		int sizePerPage = 0;
		
		if(str_sizePerPage == null) {
			sizePerPage = 3; 
		}
		
		try {
			sizePerPage = Integer.parseInt(str_sizePerPage);
			
			if(sizePerPage != 3 && sizePerPage != 5 && sizePerPage != 10) {
				sizePerPage = 3;
			}
			
		} catch (NumberFormatException e) {
			sizePerPage = 3;
		}
		
		
		String str_currentShowPage = req.getParameter("currentShowPageNo");
		int currentShowPageNo = 0;
		
		int totalPage = 0;
		int totalCountMemo = pdao.getUserOrderTotal(loginuser.getUserid());  // 총개수
		
		
		totalPage = (int)Math.ceil((double)totalCountMemo / sizePerPage);
		
		if(str_currentShowPage == null) {
			currentShowPageNo = 1;
			
		}else {
			try {
				currentShowPageNo = Integer.parseInt(str_currentShowPage);
				
				if(totalPage < currentShowPageNo || currentShowPageNo < 1) {
					currentShowPageNo = 1;
				}
				
			} catch (NumberFormatException e) {
				currentShowPageNo = 1;
			}
			
		}
		
		
		// 로그인을 했으면 주문내역을 보여준다.
		List<HashMap<String, String>> orderList = pdao.getOrderList(loginuser.getUserid(), sizePerPage , currentShowPageNo);
		req.setAttribute("orderList", orderList);
		
		// *** 메소드로 pageBar 호출하기 *** //
		String url = "orderList.do";
		int blocksize = 10;
		
		
		// *** 장바구니 수량 수정 또는 삭제후 돌아갈 페이지를 위해 현재 URL
		String currentURL = MyUtil.getCurrentURL(req);
		req.setAttribute("currentURL", currentURL);
		
		
		String pageBar = MyUtil.getPageBar(url, currentShowPageNo, sizePerPage, totalPage, blocksize);	
		req.setAttribute("pageBar", pageBar);		
		
		req.setAttribute("sizePerPage", sizePerPage);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/orderList.jsp");
		
		
	}

}
