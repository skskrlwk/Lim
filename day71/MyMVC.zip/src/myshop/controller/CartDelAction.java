package myshop.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.ProductDAO;

public class CartDelAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		String cartno = req.getParameter("cartno");
		String method = req.getMethod();
		String goBackURL = req.getParameter("goBackURL");
		System.out.println(">>>>>>>>>>>>>>>>>> goBackURL : " + goBackURL);
		MemberVO loginuser = super.getMemberLogin(req);
		// 로그인 유무 검사해주는 메소드 호출
				
		if(loginuser == null) {
			return;
			
		} else if(!method.equalsIgnoreCase("post")) {
			// post 형식이 아닐떄
			super.invalidPath(req);
			return;
		}
		
		ProductDAO dao = new ProductDAO();
		int n = dao.cartnoDelete(loginuser.getUserid(), cartno);
		
		if(n == 1) {
			super.alertMsg(req, "수정하기 완료!!", goBackURL);
			
		}else {
			super.alertMsg(req, "수정하기 실패!!", "javascript:history.back();");
		}
			
		

	}

}
