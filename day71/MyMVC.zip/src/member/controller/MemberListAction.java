package member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;
import memo.model.MemoVO;
import util.my.MyUtil;

public class MemberListAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
				
		MemberDAO mdao = new MemberDAO();
		
		String selectVal = req.getParameter("selectVal");
		String searchText = req.getParameter("searchText");
		String selDate = req.getParameter("selDate");
				
		if(selectVal == null)
			selectVal ="name";
		System.out.println("selectVal = " + selectVal);
		if(searchText == null)
			searchText ="";
		System.out.println("searchText = " + searchText);
		if(selDate == null)
			selDate ="1";
		System.out.println("selDate = " + selDate);
		
		
		String str_sizePerPage = req.getParameter("sizePerPage");
		int sizePerPage = 0;
		
		if(str_sizePerPage == null) {
			sizePerPage = 10;
			
		}else {
			try {
				sizePerPage = Integer.parseInt(str_sizePerPage);
				
				if(sizePerPage != 10 && sizePerPage != 5 && sizePerPage != 3 ) {
					sizePerPage = 10;
				}
				
			}catch (NumberFormatException e) {
				sizePerPage = 10;
			}
		}
		
		int totalPage = 0;
		int totalCountMemo = mdao.getCountMember(selectVal, searchText, selDate);//112
		totalPage = (int)Math.ceil((double)totalCountMemo / sizePerPage);
		
		String str_currentShowPage = req.getParameter("currentShowPageNo");
		int currentShowPageNo = 0;
		
		if(str_currentShowPage == null) {
			currentShowPageNo = 1;
			
		}else {
			try {
				currentShowPageNo = Integer.parseInt(str_currentShowPage);
				
				if(totalPage < currentShowPageNo || currentShowPageNo < 1) {
					currentShowPageNo = 1;
				}
				
			} catch (NumberFormatException e) {
				currentShowPageNo = 1;
			}
			
		}
		
		List<MemberVO> memList = null;
		
		// 세션 받아오기
		HttpSession session = req.getSession();
		MemberVO loginuser = (MemberVO)session.getAttribute("loginuser");
		if(loginuser == null) {
			String msg = "로그인 사용자만 가능합니다.";
			String loc = "index.do";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			return;
		}else if(loginuser != null && !"admin".equals(loginuser.getUserid())) {
			// 일반 사용자로 로그인 했을시
			memList = mdao.getSearchMember(selectVal, searchText, selDate, currentShowPageNo, sizePerPage);
		}else if(loginuser != null && "admin".equals(loginuser.getUserid())) {
			// 관리자로 로그인 했을시
			memList = mdao.getSearchMemberWithDel(selectVal, searchText, selDate, currentShowPageNo, sizePerPage);
		}
			
		
		
		
		// *** 메소드로 pageBar 호출하기 *** //
		String url = "memberList.do";
		int blocksize = 10;
		
		String pageBar = MyUtil.getPageBar(url, currentShowPageNo, sizePerPage, totalPage, blocksize, selectVal, searchText, selDate);
		req.setAttribute("pageBar", pageBar);
		
				
		req.setAttribute("sizePerPage", sizePerPage);
		req.setAttribute("memList", memList);
		req.setAttribute("selectVal", selectVal);
		req.setAttribute("searchText", searchText);
		req.setAttribute("selDate", selDate);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/member/memberList.jsp");
		
		
	}

}
