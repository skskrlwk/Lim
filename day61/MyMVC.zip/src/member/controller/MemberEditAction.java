package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;

public class MemberEditAction extends AbstractController{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		MemberDAO mdao = new MemberDAO();
		MemberVO vo = new MemberVO();
		String idx = req.getParameter("idx");
		
		vo = mdao.getMember(idx);
		
		req.setAttribute("vo", vo);
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/member/memberEdit.jsp");
		
	}

}
