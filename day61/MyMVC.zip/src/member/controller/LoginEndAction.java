package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;
import util.my.MyUtil;

public class LoginEndAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
				
		String method = req.getMethod();
		
		String goBackURL = req.getParameter("goBackURL");
		MemberVO membervo = null;
		
		if(!method.equalsIgnoreCase("post")) {
			// POST 방식으로 넘어온것이 아니라면
			String msg = "비정상적인 경로로 들어왔습니다.";
			String loc = "javascript:history.back()";
			
			req.setAttribute("msg", msg);
			req.setAttribute("loc", loc);
			
			super.setRedirect(false);
			super.setViewPage("/WEB-INF/msg.jsp");
			
			
		}else {
			// POST 방식으로 넘어온 것
			String userid = req.getParameter("userid");
			String pwd = req.getParameter("pwd");
			
			// 사용자로 부터 입력받은 userid 와 pwd 값이
			// jsp_member 테이블에 존재하는지 여부를 알아야 한다.
			MemberDAO memberdao = new MemberDAO();
			
			membervo= memberdao.loginOKmemberInfo(userid, pwd);
			
			if(membervo == null) {
				// 로그인 실패
				String msg = "아이디 또는 비밀번호가 틀렸습니다.";
				String loc = "javascript:history.back()";
				
				req.setAttribute("msg", msg);
				req.setAttribute("loc", loc);
				
				super.setRedirect(false);
				super.setViewPage("/WEB-INF/msg.jsp");
				
			}else {
				// 로그인 성공
				// 로그인 되어진 사용자의 정보(membervo)를 세션(session)에 저장시킨다.
				// *** 세션(session)
				// 세션(session)은 WAS(톰캣서버)의 메모리(RAM)의 일부분을 사용하는 저장공간이다.
				// 세션(session)에 저장된 데이터는 모든 파일(*.do, *.jsp)에서 
				// 사용할 수 있도록 접근이 가능하다.
				HttpSession session =  req.getSession(); // jsp 에는 바로 session 으로 사용가능하다 (내장함수)
				session.setAttribute("loginuser", membervo);
						
				super.setRedirect(true); // redirect 방식으로 페이지 이동만 한다.		
			//	super.setViewPage("index.do");
				super.setViewPage(goBackURL);
			}

			
		}
		
	}

}
