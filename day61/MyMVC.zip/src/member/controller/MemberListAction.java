package member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;
import memo.model.MemoVO;
import util.my.MyUtil;

public class MemberListAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		MemberDAO mdao = new MemberDAO();
		
		String str_sizePerPage = req.getParameter("sizePerPage");
		int sizePerPage = 0;
		
		if(str_sizePerPage == null) {
			sizePerPage = 10;
			
		}else {
			try {
				sizePerPage = Integer.parseInt(str_sizePerPage);
				
				if(sizePerPage != 10 && sizePerPage != 5 && sizePerPage != 3 ) {
					sizePerPage = 10;
				}
				
			}catch (NumberFormatException e) {
				sizePerPage = 10;
			}
		}
		
		int totalPage = 0;
		int totalCountMemo = mdao.getTotalCount(); //112
		totalPage = (int)Math.ceil((double)totalCountMemo / sizePerPage);
		
		String str_currentShowPage = req.getParameter("currentShowPageNo");
		int currentShowPageNo = 0;
		
		if(str_currentShowPage == null) {
			currentShowPageNo = 1;
			
		}else {
			try {
				currentShowPageNo = Integer.parseInt(str_currentShowPage);
				
				if(totalPage < currentShowPageNo || currentShowPageNo < 1) {
					currentShowPageNo = 1;
				}
				
			} catch (NumberFormatException e) {
				currentShowPageNo = 1;
			}
			
		}
		
		List<MemberVO> memList = mdao.getAllMember(currentShowPageNo, sizePerPage);		
		
		// *** 메소드로 pageBar 호출하기 *** //
		String url = "memberList.do";
		int blocksize = 10;
		
		String pageBar = MyUtil.getPageBar(url, currentShowPageNo, sizePerPage, totalPage, blocksize);	
		req.setAttribute("pageBar", pageBar);
		
		
		
		
		
		
		
		req.setAttribute("sizePerPage", sizePerPage);
		req.setAttribute("memList", memList);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/member/memberList.jsp");
		
	}

}
