package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.MemberVO;
import util.my.MyUtil;

public class MemberDetailAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		String url = MyUtil.getCurrentURL(req);
		int index = url.indexOf("?");
		url = url.substring(index+1);
		index = url.indexOf("=");
		url = url.substring(index+1);
		
		String str_idx= url;
		
		
		
		MemberDAO mdao = new MemberDAO();
		MemberVO vo = null;
		
		vo = mdao.getMember(str_idx);
		
		req.setAttribute("vo", vo);
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/member/memberDetail.jsp");
		
	}

}
