package myshop.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.ProductDAO;

public class OdrcodeInfoAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {

		super.getCategoryList(req);
		
		String ordcode = req.getParameter("ordcode");
		System.out.println("ordcode >>>>>>>>>>" + ordcode);
		
		HttpSession session = req.getSession();
		MemberVO loginuser = (MemberVO)session.getAttribute("loginuser");
		
		if(loginuser == null) {
			super.invalidPath(req);	
		} 
		else if(!loginuser.getUserid().equals("admin")) {
			super.invalidPath(req);
		}
		 
		ProductDAO dao = new ProductDAO();
		MemberVO vo = dao.getMemberInfo(ordcode);
		
		req.setAttribute("vo", vo);
		
		
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/odrcodeInfo.jsp");
		
		
	}

}
