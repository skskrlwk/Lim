package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import myshop.model.ProductDAO;
import myshop.model.ProductVO;

public class DisplayAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		// *** 카테고리 목록 가져와서 왼쪽 로그인폼 아래에 보여주도록 한다. *** //
		super.getCategoryList(req);
		
		ProductDAO dao = new ProductDAO();
				
		// 1. HIT 상품 가져오기
		List<ProductVO> hitList = dao.selectByPspec("HIT"); // 페이징 처리 안한것.
		
		req.setAttribute("hitList", hitList);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/malldisplay.jsp");
				
		
	}

}
