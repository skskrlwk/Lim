package ajax.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class AjaxDAO implements InterAjaxDAO {
	
	private DataSource ds;
	// 객체변수 ds는 아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 이다. (import javax.sql.DataSource)
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	/* 
	   === AjaxDAO 생성자에서 해야할 일은 === 
	   아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 객체인 ds 를 빌려오는 것이다.  
	*/
	public AjaxDAO() {
		try {
			Context initContext = new InitialContext(); // javax.naming 을 import한다.
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
			
		} catch (NamingException e) {
			e.printStackTrace(); 
		}
		
	}// end of MemoDAO()---------------------------------
	

	// *** 사용한 자원을 반납하는 close() 메소드 생성하기 *** //
	public void close() {
		try {
			
			if(rs != null) {
				rs.close();
				rs = null;
			}
			
			if(pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			if(conn != null) {
				conn.close();
				conn = null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}// end of close()------------------------------------


	// *** tbl_images 테이블의 모든 행을 조회하는 메소드 *** //
	@Override
	public List<ImageVO> getTblImages() throws SQLException {
		List<ImageVO> imgList = null;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select userid, name, img "
						+" from tbl_images ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt ++;
				
				if(cnt == 1) {
					imgList = new ArrayList<ImageVO>();
				}
					
				String userid = rs.getString("userid");
				String name = rs.getString("name");
				String img = rs.getString("img");
				
				ImageVO vo = new ImageVO(userid, name, img);
				imgList.add(vo);
			}
			
			
		} finally {
			close();
		}
		
		return imgList;
	}// end of getTblImages() ------------------------------------


	// *** tbl_ajaxnews 테이블에 입력된 데이터중 오늘 날짜에 해당하는 행만 추출(select) 하는 메소드 *** //
	@Override
	public List<TodayNewsVO> getNewsTitleList() throws SQLException {
		List<TodayNewsVO> todayNewsList = null;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select seqtitleno, "
						+" case when length(title) > 22 then substr(title, 1, 20)||'..' else title end as title, "
						+" to_char(registerday, 'yyyy-mm-dd') as registerday "
						+" from tbl_ajaxnews "
						+" where to_char(registerday, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd') ";
						
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt ++;
				
				if(cnt == 1) {
					todayNewsList = new ArrayList<TodayNewsVO>();
				}
					
				int seqtitleno = rs.getInt("seqtitleno");
				String title = rs.getString("title");
				String registerday = rs.getString("registerday");
				
				TodayNewsVO vo = new TodayNewsVO(seqtitleno, title, registerday);
				todayNewsList.add(vo);
			}
			
		} finally {
			close();
		}
		
		return todayNewsList;
	}// end of getNewsTitleList() -----------------------------------


	// *** tbl_books 테이블에 있는 모든 정보를 조회하는 메소드 *** //
	@Override
	public List<BookVO> getAllBooks() throws SQLException {
		List<BookVO> listBook = null;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select subject, title, author, to_char(registerday, 'yyyy-mm-dd') as registerday "
						+" from tbl_books "
						+" where to_date( to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd') - to_date( to_char(registerday, 'yyyy-mm-dd'), 'yyyy-mm-dd') <= 7  "
						+" order by subject asc, registerday desc ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt ++;
				
				if(cnt == 1) {
					listBook = new ArrayList<BookVO>();
				}
				String subject = rs.getString("subject");
				String title = rs.getString("title");
				String author = rs.getString("author");
				String registerday = rs.getString("registerday");
				
				BookVO vo = new BookVO(subject, title, author, registerday);
				listBook.add(vo);
				
			}
			
		} finally {
			close();
		}
		
		
		return listBook;
	}// end of getAllBooks() -------------------------------------
	
	
}
