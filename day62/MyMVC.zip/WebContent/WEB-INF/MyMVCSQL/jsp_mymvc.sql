-------------- *** JSP & Servlet *** ---------------

-------------- *** MyMVC *** ------------------

show user;
-- USER��(��) "MYORAUSER"�Դϴ�.

--- 1. ���� �޸��� ---
create table jsp_memo
(idx number(8) not null, -- �۹�ȣ(�������� �Է�)
 userid varchar2(20) not null, -- ȸ�� ���̵�
 name varchar2(20) not null, -- �ۼ��� �̸� 
 msg varchar2(100), -- �޸𳻿�
 writedate date default sysdate, -- �ۼ�����
 cip varchar2(20), -- Ŭ���̾�Ʈ IP �ּ�
 status number(1) default 1 not null, -- �ۻ��� ���� 
 constraint PK_jsp_memo_idx primary key(idx),
 constraint FK_jsp_memo_userid foreign key(userid)
                                references jsp_member(userid),
 constraint CK_jsp_memo_status check(status in(0,1))                                
);

create sequence jsp_memo_idx
start with 1
increment by 1
nomaxvalue
nominvalue
nocycle
nocache;

select *
from jsp_memo
order by idx desc;


select *
from jsp_member
order by idx desc;

select A.idx, A.msg, to_char(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
       A.cip, B.name, B.email
from jsp_memo A join jsp_member B
on A.userid = B.userid
where A.status = 1
order by idx desc;


+"SELECT A.idx, " 
+"  A.msg, " 
+"  TO_CHAR(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate, " 
+"  A.cip, " 
+"  B.name " 
+"FROM jsp_memo A " 
+"JOIN jsp_member B " 
+"ON A.userid    = B.userid " 
+"WHERE A.status = 1 " 
+"ORDER BY idx DESC;"


------ *** ���� �÷��߰� *** ------ 
alter table jsp_member  -- ���� : 1 / ���� : 2
add gender char(1);

-- *** ������� �÷� �߰� *** --
alter table jsp_member
add birthday varchar2(8);

-------------------------------------------------------
update jsp_member set gender = '2'
where name like '%��ȭ%' or name like '%����%';

update jsp_member set gender = '1'
where not (name like '%��ȭ%' or name like '%����%');

commit;

update jsp_member set birthday = '19850420'
where idx between 1 and 30;

update jsp_member set birthday = '19900825'
where idx between 31 and 60;

update jsp_member set birthday = '19931001'
where idx between 61 and 90;

update jsp_member set birthday = '19950515'
where idx between 91 and 120;

update jsp_member set birthday = '19970925'
where idx between 121 and 150;

update jsp_member set birthday = '20010220'
where idx between 151 and 180;

update jsp_member set birthday = '20021210'
where idx between 181 and 210;

commit;update jsp_member set birthday = '19850420'
where idx between 1 and 30;

commit;

select *
from jsp_member
order by idx desc;

select A.idx, A.msg, to_char(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
       A.cip, B.name, B.email, B.gender,
      ( extract(year from sysdate)  - to_number(substr(B.birthday,1,4)) ) + 1 AS age
from jsp_memo A join jsp_member B
on A.userid = B.userid
where A.status = 1
order by idx desc;

declare 
  v_cnt number(3) := 1;

begin
  loop 
    insert into jsp_memo(idx, userid, name, msg, writedate, cip, status)
    values(jsp_memo_idx.nextval, 'leess', '�̼���', v_cnt || '�ȳ��ϼ���? �̼����Դϴ�.', default, '127.0.0.1', default);
    v_cnt := v_cnt + 1;
  exit when v_cnt > 100;
  end loop;
end;

select *
from jsp_memo;

commit;

SELECT idx, msg, writedate, cip, name, email, gender, age, status
FROM
(
  SELECT rownum AS RNO, idx, msg, writedate,
          cip, name, email, gender, age, status
  From
  (
    SELECT A.idx, A.msg, 
           TO_CHAR(A.writedate, 'yyyy-mm-dd hh24:mi:ss') AS writedate,
           A.cip, B.name,	 B.email,  B.gender, A.status,
           extract(year from sysdate) - to_number(substr(B.birthday,1,4)) + 1 AS age 
    FROM jsp_memo A JOIN jsp_member B  
    ON A.userid = B.userid 
    WHERE A.status = 1 
    ORDER BY idx DESC
  )V
)T
WHERE t.rno between 1 and 10


select *
from jsp_memo
order by 1 desc;

select *
from jsp_member
order by 1 desc;


select idx, userid, name, pwd, email, hp1, hp2, hp3, addr1, addr2, registerday, status, gender, birthday
from jsp_member

select count(*) AS CNT
from jsp_member
where userid = 'leess'


select *
from jsp_member
order by 1 desc;


select idx, userid, name, pwd, email, hp1, hp2, hp3,
       post1, post2, addr1, addr2,
       to_char(registerday, 'yyyy-mm-dd') as registerday,
       status, gender, birthday
from jsp_member
where status = 1 and userid = 'leess' and pwd = 'qwer1234$'

select userid
from jsp_member 
where status = 1 and 
name = ? and 
trim(hp1) || trim(hp2) || trim(hp3) = 01011111111;
