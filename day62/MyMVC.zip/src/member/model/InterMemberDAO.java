package member.model;

import java.sql.*;
import java.util.*;

public interface InterMemberDAO {

	// *** 중복 아이디 여부를 체크하는 메소드 *** //
	boolean idDuplicateCheck(String userid) throws SQLException;
	
	// *** 우편번호 찾기 추상 메소드 *** //
	List<ZipcodeVO> getZipcode(String dong) throws SQLException;
	
	// *** 회원 가입하기 추상 메소드 *** //
	int registerMember(MemberVO mvo) throws SQLException;
	
	// *** 페이징처리를 안한 전체회원을 보여주는 추상 메소드 *** //
	List<MemberVO> getAllMember() throws SQLException;
	
	// ** 페이징처리를 위한 사용가능한(탈퇴안한사람) 전체 회원수를 알려주는 추상 메소드 ** //
	int getTotalCount() throws SQLException;
	
	// *** 페이징처리를 한 전체회원을 보여주는 추상 메소드 *** //
	List<MemberVO> getAllMember(int currentShowPageNo, int sizePerPage) throws SQLException;
	
	// *** 회원을 삭제(updqte 로 처리) 해주는 추상 메소드 *** //
	int deleteMember(String idx) throws SQLException;
	
	// *** 회원의 정보를 알려주는 추상 메소드 *** //
	MemberVO getMember(String str_idx) throws SQLException;
	
	// *** 회원의 정보를 수정해주는 추상 메소드 *** //
	int updateMember(MemberVO mvo) throws SQLException;
	
	// *** 검색된 회원의 명수를 알려주는 추상 메소드 
	int getCountMember(String selectVal, String searchText, String selDate) throws SQLException;
		
	// *** (일반 사용자용)검색된 정보를 알려주는 추상 메소드 ***//
	List<MemberVO> getSearchMember(String selectVal, String searchText, String selDate, int currentShowPageNo, int sizePerPage) throws SQLException;
	
	// *** (관리용)검색된 정보를 알려주는 추상 메소드 ***//
	List<MemberVO> getSearchMemberWithDel(String selectVal, String searchText, String selDate, int currentShowPageNo, int sizePerPage) throws SQLException;
	
	// ** 로그인 처리(로그인 성공: 회원정보를 리턴, 로그인이 실패: null 리턴) 해주는 추상 메소드 ** //
	MemberVO loginOKmemberInfo(String userid, String pwd) throws SQLException;
	
	// *** 삭제된 회원을 복구(update 처리)해주는 추상 메소드 *** //
	int recoverMember(String idx) throws SQLException;
	// *** ID 찾기를 해주는 추상 메소드 ***//
	String getUserid(String name, String mobile) throws SQLException;
	
	
	
}

