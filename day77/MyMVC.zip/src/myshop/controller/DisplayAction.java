package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import myshop.model.InterProductDAO;
import myshop.model.ProductDAO;
import myshop.model.ProductVO;

public class DisplayAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		// *** 카테고리 목록 가져와서 왼쪽 로그인폼 아래에 보여주도록 한다. *** //
		super.getCategoryList(req);
		
		InterProductDAO dao = new ProductDAO();
	/*			
		// 1. HIT 상품 가져오기
		List<ProductVO> hitList = dao.selectByPspec("HIT"); // 페이징 처리 안한것.
		
		req.setAttribute("hitList", hitList);
	*/	
		int totalHitcount = dao.totalSpecCount("HIT");
		// 상품들의 목록을 페이징하기 위하여 총개수를 알아온다
		req.setAttribute("totalHitcount", totalHitcount);
		
		int totalNewcount = dao.totalSpecCount("NEW");
		// 상품들의 목록을 페이징하기 위하여 총개수를 알아온다
		req.setAttribute("totalNewcount", totalNewcount);
		
		
		super.setRedirect(false);
	//	super.setViewPage("/WEB-INF/myshop/malldisplay.jsp"); // 페이징 처리 이전.
		super.setViewPage("/WEB-INF/myshop/malldisplayAjax.jsp"); 
		// Ajax(XML, JSON)를 사용하여 상품목록의 페이징 처리를 더보기 방식으로 한것임.
		
	}

}
