package member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractController;
import member.model.MemberDAO;
import member.model.ZipcodeVO;

public class ZipcodeInfoAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {

		MemberDAO mdao = new MemberDAO();
		
		String dong = req.getParameter("dong");
		 
		List<ZipcodeVO> zipList = mdao.getZipcode(dong);
		
		req.setAttribute("zipList", zipList);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/member/zipcodeInfo.jsp");
		
	}

}
