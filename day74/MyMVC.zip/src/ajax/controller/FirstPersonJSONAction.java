package ajax.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import common.controller.AbstractController;

public class FirstPersonJSONAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		JSONObject PersonObj = new JSONObject();
		
		PersonObj.put("name", "이순신");
		PersonObj.put("age", new Integer(27));
		PersonObj.put("height", new Double(171.5));
		PersonObj.put("phone", "010-345-6789");
		PersonObj.put("email", "leess@gmail.com");
		PersonObj.put("address", "서울시 강남구 도곡동");
		
		String str_personInfo = PersonObj.toString();
		// JSONObject PersonObj 을 String 으로 변환하기
		
		System.out.println("===> 확인용 JSON 형태의 personObj 의 값 : " + str_personInfo);
		// {"address":"서울시 강남구 도곡동","phone":"010-345-6789","name":"이순신","age":27,"email":"leess@gmail.com","height":171.5}
		
		req.setAttribute("str_personInfo", str_personInfo);
		
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/1personInfoJSON.jsp");
		
		
	}

}
