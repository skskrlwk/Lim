package ajax.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import common.controller.AbstractController;
import member.model.InterMemberDAO;
import member.model.MemberDAO;
import member.model.MemberVO;

public class ThirdMemberListJSONAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {

		String name = req.getParameter("name");
		
		InterMemberDAO mdao = new MemberDAO();
		
		List<MemberVO> memberList = mdao.getSearcgMembers(name);
		
		JSONArray jsonArr = new JSONArray();
		
		if(memberList != null && memberList.size() > 0) {
			
			for(MemberVO vo : memberList) {
				JSONObject obj = new JSONObject();
				obj.put("name", vo.getName());
				obj.put("email", vo.getEmail());
				obj.put("addr", vo.getAllAddr());
				
				jsonArr.add(obj);
			}
			
		}
		
		
		req.setAttribute("jsonArr", jsonArr);
		super.setRedirect(false);
		super.setViewPage("/AjaxStudy/chap4/3memberInfo.jsp");
		

	}

}
