package myshop.model;

import java.sql.SQLException;
import java.util.*;

import member.model.MemberVO;

public interface InterProductDAO {

	// *** jsp_product 테이블에서  pspec 컬럼의 값(HIT, NEW, BEST)별로 상품목로드를 가져오는 추상메소드 *** //
	List<ProductVO> selectByPspec(String pspec) throws SQLException;
	
	// *** jsp_product 테이블에서 pnum으로 제품1개의 정보를 받아오는 추상 메소드 *** //
	ProductVO getProductOneByPnum(String pnum) throws SQLException;

	// *** jsp_cart 테이블(장바구니 테이블)에 물건을 입력해주는 추상메소드 *** //
	int addCart(String userid, String pnum, String oqty) throws SQLException;
	
	// *** (페이징처리 전)jsp_cart 테이블(장바구니 테이블)을 조회해주는 추상 메소드 *** //
	List<CartVO> getCartList(String userid) throws SQLException;
	
	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 있는 수량을 변경하는 추상 메소드 *** // 
	int oqtyUpdate(String userid, String cartno, String oqty) throws SQLException;
	
	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 총개수를 가져오는 추상 메소드 ** //
	int getCartTotal(String userid) throws SQLException;
	
	// *** (페이징처리) jsp_cart 테이블(장바구니 테이블)을 조회해주는 추상 메소드 *** //
	List<CartVO> getCartList(String userid, int sizePerPage, int currentShowPageNo) throws SQLException;
	
	// *** cartno로 jsp_cart 테이블(장바구니 테이블)에 있는 정보를 삭제하는 추상 메소드 *** // 
	int cartnoDelete(String userid, String cartno) throws SQLException;

	// *** jsp_product_imagefile 테이블에서 복수개 이미지 파일을 출력해주는 추상 메소드  *** //
	List<ProductImagefileVO> getProductImagefileByPnum(String pnum) throws SQLException;
	
	
	// *** jsp_category 테이블에서 카테고리코드(code)와 카테고리명(cname)을 가져오는 추상 메소드 *** //
	List<CategoryVO> getCategoryList() throws SQLException;
	
	// *** jsp_product 테이블에서  code값으로 pspec 컬럼의 값(HIT, NEW, BEST)별로 상품목로드를 가져오는 추상메소드 *** //
	List<ProductVO> selectByPspec(String pspec, String code) throws SQLException;
	
	// *** 주문코드(명세서번호)시퀀스 값 가져오는 추상 메소드 *** //
	int getSeq_jsp_order() throws SQLException;
	
	// *** 주문하기(transaction 처리) 추상메소드 *** //
	/*
	 	==== *** Transaction 처리하기 *** ====
	 	1. 주문개요 테이블(jsp_order)에 입력(insert)
	 	2. 주문상세 테이블(jsp_order_detail)에 입력(insert)
	 	3. 구매하는 사용자의 coin 컬럼의 값을 구매한 가격만큼 차감하고(update),
	 	   point 컬럼의 값은 구매한 포인트만큼 증가(update).
	  	4. 주문한 제품의 잔고량은 주문량 만큼 차감해야 하고(update)
	 	5. 장바구니에서 주문을 한 것이라면 장바구니 비우기(status 컬럼을 0으로 변경한다. 원래는 delete)
	 	를 해주는 DAO에서 만든 메소드 호출하기
	 */
	int add_Order_OrderDetail(String odrcode, String userid, int sumtotalprice, int sumtotalpoint,
								String[] pnumArr, String[] oqtyArr, String[] salepriceArr, String[] cartnoArr) throws SQLException;
	
	
	// *** 제품번호들에 해당하는 제품목록을 조회해오는 추상 메소드 *** //
	List<ProductVO> getJumunfinishProductList(String pnumes) throws SQLException;
	
	// *** 유저아이디로 주문한량의 총개수를 알아오는 추상 메소드 *** //
	int getUserOrderTotal(String userid) throws SQLException;
	
	// *** 전체 주문내역의 총개수를 알아오는 추상 메소드 *** //
	int getAllOrderTotal() throws SQLException;
	
	// *** 유저아이디로 주문한 내용 및 주문한 제품의 정보를 가져오는 추상 메소드 ***(HashMap) //
	List<HashMap<String, String>> getOrderList(String userid, int sizePerPage , int currentShowPageNo) throws SQLException;
	
	// *** 주문코드로 유저정보를 가져오는 추상 메소드 *** //
	MemberVO getMemberInfo(String ordcode) throws SQLException;
	
	// *** 주문코드와 제품번호로 배송준비에서 시작으로 변경하는 추상 메소드 *** //
	int updateDeliverStart(String odrcodePnum, int length) throws SQLException;
	
	// *** 주문코드와 제품번호로 배송시작에서 완료로 변경하는 추상 메소드 *** //
	int updateDeliverEnd(String odrcodePnum, int length) throws SQLException;
	
	// ***  jsp_product 테이블에 신규제품으로 insert 되어질 "제품번호" 시퀀스를 가져오는 추상메소드. *** //
	int getPnumOfProduct() throws SQLException;
	

	// *** 제품등록(신규상품등록)을 해주는 추상메소드 ** //
	int productInsert(ProductVO pvo) throws SQLException;
	
	// *** 제품등록(신규상품등록)시 추가이미지 파일정보를 jsp_product_imagefile 테이블에 insert 해주는 추상 메소드***//
	int product_imagefile_insert(int pnum, String attachFilename) throws SQLException; 
	
	// *** 로그인한 사용자의 구매 통계 현황을 조회해주는 추상메소드 *** //
	List<HashMap<String, String>> getMyOrderStatics(String userid) throws SQLException;
	
	// ** 제품 카테고리별 월별 판매 통계 현황을 조회해오는 추상메소드** //
	List<HashMap<String, String>> TotalOrderStatics() throws SQLException;
	
	// ** jsp_like 테이블에 insert 를 해주는 추상 메소드 ** //
	int insertLike(String userid, String pnum) throws SQLException;
	
	// ** jsp_dislike 테이블에 insert 를 해주는 추상 메소드 ** //
	int insertDislike(String userid, String pnum) throws SQLException;
	
	// ** jsp_like 테이블과 jsp_dislike 테이블에서 특정 제품에 대한 count(*)를 조회하는 추상 메소드 ** //
	HashMap<String, String> getLikeDislikeCount(String pnum) throws SQLException;
}
