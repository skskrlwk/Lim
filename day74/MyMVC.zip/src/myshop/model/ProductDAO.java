package myshop.model;

import java.sql.*;
import java.util.*;

import javax.naming.*;
import javax.sql.DataSource;

import member.model.MemberVO;

public class ProductDAO implements InterProductDAO {
	
	private DataSource ds;
	// 객체변수 ds는 아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 이다. (import javax.sql.DataSource)
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	/* 
	  	=== ProductDAO 생성자에서 해야할 일은 === 
	   	아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 객체인 ds 를 빌려오는 것이다.  
	*/
	public ProductDAO() {
		try {
			Context initContext = new InitialContext(); // javax.naming 을 import한다.
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
			
		} catch (NamingException e) {
			e.printStackTrace(); 
		}
		
	}// end of ProductDAO()---------------------------------
	

	// *** 사용한 자원을 반납하는 close() 메소드 생성하기 *** //
	public void close() {
		try {
			
			if(rs != null) {
				rs.close();
				rs = null;
			}
			
			if(pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			if(conn != null) {
				conn.close();
				conn = null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}// end of close()------------------------------------


	// *** jsp_product 테이블에서 pspec 컬럼의 값(HIT, NEW, BEST) 별로 상품 목록을 가져오는 메소드 생성하기 *** // 
	@Override
	public List<ProductVO> selectByPspec(String p_spec)	throws SQLException {
		
		List<ProductVO> productList = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pspec = ? "
					+   "  order by pnum desc ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, p_spec);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;

				if(cnt==1)
					productList = new ArrayList<ProductVO>();

				int pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    ProductVO pvo = new ProductVO(pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  
			    
			    productList.add(pvo);
			    
			}// end of while-----------------
						
		} finally{
			close();
		}
				
		return productList;
	}// end of selectByPspec(String pspec)------------------------------------


	// *** jsp_product 테이블에서 pnum으로 제품1개의 정보를 받아오는 메소드 *** //
	@Override
	public ProductVO getProductOneByPnum(String pnum) throws SQLException {
		ProductVO vo = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pnum = ? ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, pnum);
			
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				int i_pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    vo = new ProductVO(i_pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  			
			}
				
		} finally{
			close();
		}
		
		
		return vo;
	}// end of getProductOneByPnum(String pnum) ---------------------------------

	// *** jsp_cart 테이블(장바구니 테이블)에 물건을 입력해주는 메소드 *** //
	@Override
	public int addCart(String userid, String pnum, String oqty) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			
			/*
			 	먼저 장바구니 테이블(jsp_cart)에 새로운 제품은 넣는 것인지,
			 	아니면 또다시 제품을 추가로 더 구매하는 것인지 알기 위해서
			 	사용자가 장바구니에 넣으려고 하는 제품번호가 장바구니 테이블에
			 	이미 있는지 먼저 장바구니번호(cartno)의 값을 알아온다.
			 */
			
			String sql = " select cartno "
						+" from jsp_cart "
						+" where status = 1 and "
						+" 		 userid = ? and "
						+"		 pnum = ? "; 
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, pnum);
			
			rs = pstmt.executeQuery();
				
			if(rs.next()) {
				// 이미 장바구니 테이블에 담긴 제품이라면 update 해준다.
				int cartno = rs.getInt("cartno");
				
				sql = " update jsp_cart set oqty = oqty + ? "
					+ " where cartno = ? ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(oqty));
				pstmt.setInt(2, cartno);
				
				result = pstmt.executeUpdate();
				
			} else {
				// 장바구니 테이블에 없는 제품이라면 insert 해준다.
				sql = " insert into jsp_cart(cartno, userid, pnum, oqty) "
					+ " values(seq_jsp_cart_cartno.nextval, ?, to_number(?), to_number(?) ) ";
			
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				pstmt.setString(3, oqty);
				
				result = pstmt.executeUpdate();
			}
			
		} finally {
			close();
		}
		
		return result;
	}// end of addCart(String userid, String pnum, String oqty) ----------------------------


	// *** jsp_cart 테이블(장바구니 테이블)을 조회해주는 메소드 *** //
	@Override
	public List<CartVO> getCartList(String userid) throws SQLException {
		
		List<CartVO> cartList = null;
		try {
			conn = ds.getConnection();
			
			String sql = "SELECT B.cartno, " 
						+"  B.userid, " 
						+"  B.pnum, " 
						+"  A.pname, " 
						+"  A.pcategory_fk, " 
						+"  A.pimage1, " 
						+"  A.price, " 
						+"  A.saleprice, " 
						+"  B.oqty, " 
						+"  A.point, " 
						+"  B.status " 
						+"FROM jsp_product A " 
						+"JOIN jsp_cart B " 
						+"ON A.pnum      = B.pnum " 
						+"WHERE B.userid = ? " 
						+"AND B.status   = 1 " 
						+"ORDER BY B.cartno DESC";
			
			pstmt =conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				
				cnt ++;
				if(cnt == 1) {
					cartList = new ArrayList<CartVO>();
				}
				
				int cartno = rs.getInt("cartno");
				userid = rs.getString("userid");
				int pnum = rs.getInt("pnum");
				String pname = rs.getString("pname");
				String pcategory_fk = rs.getString("pcategory_fk");
				String pimage1 = rs.getString("pimage1");
				int price = rs.getInt("price");
				int saleprice = rs.getInt("saleprice");
				int oqty = rs.getInt("oqty");
				int point = rs.getInt("point");
				int status = rs.getInt("status");
				
				CartVO cvo = new CartVO();
				cvo.setCartno(cartno);
				cvo.setUserid(userid);
				cvo.setPnum(pnum);
				cvo.setOqty(oqty);
				cvo.setStatus(status);
				
				ProductVO item = new ProductVO();
				item.setPnum(pnum);
				item.setPrice(price);
				item.setSaleprice(saleprice);
				item.setPimage1(pimage1);
				item.setPcategory_fk(pcategory_fk);
				item.setPname(pname);
				item.setPoint(point);
				
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				item.setTotalPriceTotalPoint(oqty);
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				
				cvo.setItem(item);
				
				cartList.add(cvo);
			}
			
			
		} finally {
			close();
		}
		
		return cartList;
		
	}// end of getCartList(String userid) -------------------------------------------

	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 있는 수량을 변경하는 추상 메소드 *** // 
	@Override
	public int oqtyUpdate(String userid, String cartno, String oqty) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			
			if(Integer.parseInt(oqty) == 0) {
				// 입력된 수량값이 0이거나 음수값일때
				String sql = " update jsp_cart set status = 0 "
						+" where userid = ? and cartno = ? ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, cartno);
				
				result = pstmt.executeUpdate();
				
				
			}else {
				// 
				String sql = " update jsp_cart set oqty = ? "
						+" where userid = ? and cartno = ? ";
					
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, oqty);
				pstmt.setString(2, userid);
				pstmt.setString(3, cartno);
				
				result = pstmt.executeUpdate();
				
			}
			
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of oqtyUpdate(String userid, String cartno, String oqty)


	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 총개수를 가져오는 메소드 ** //
	@Override
	public int getCartTotal(String userid) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			String sql = " select count(*) AS CNT "
						+" from jsp_cart"
						+" where status = 1 and "
						+" 		 userid = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			
			rs = pstmt.executeQuery();
			boolean bool = rs.next();
			if(bool) {
				result = rs.getInt("CNT");
			}
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of getCartTotal(String userid) ----------------------------------


	@Override
	public List<CartVO> getCartList(String userid, int sizePerPage, int currentShowPageNo) throws SQLException {
		
		List<CartVO> cartList = null;
		try {
			conn = ds.getConnection();
			
			String sql = " SELECT cartno, userid, pnum, pname, pcategory_fk, pimage1, price, saleprice, " 
						+" 		  oqty, point, status " 
						+" FROM " 
						+"  ("
						+"	 SELECT rownum AS RNO, cartno, userid, pnum, pname, pcategory_fk, " 
						+"    		pimage1, price, saleprice, oqty, point, status " 
						+"   FROM " 
						+"    ( "
						+"		SELECT B.cartno, B.userid, B.pnum, A.pname, A.pcategory_fk, A.pimage1, " 
						+"      	   A.price, A.saleprice, B.oqty, A.point, B.status " 
						+"    	FROM jsp_product A " 
						+"      JOIN jsp_cart B " 
						+"      ON A.pnum      = B.pnum " 
						+"      WHERE B.userid = ? " 
						+"      AND B.status   = 1 " 
						+"      ORDER BY B.pnum " 
						+"    )V " 
						+"  )T " 
						+" WHERE rno BETWEEN ? AND ? ";
			
			pstmt =conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setInt(2, (currentShowPageNo*sizePerPage)-(sizePerPage-1) );
			pstmt.setInt(3, (currentShowPageNo*sizePerPage));
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				
				cnt ++;
				if(cnt == 1) {
					cartList = new ArrayList<CartVO>();
				}
				
				int cartno = rs.getInt("cartno");
				userid = rs.getString("userid");
				int pnum = rs.getInt("pnum");
				String pname = rs.getString("pname");
				String pcategory_fk = rs.getString("pcategory_fk");
				String pimage1 = rs.getString("pimage1");
				int price = rs.getInt("price");
				int saleprice = rs.getInt("saleprice");
				int oqty = rs.getInt("oqty");
				int point = rs.getInt("point");
				int status = rs.getInt("status");
				
				CartVO cvo = new CartVO();
				cvo.setCartno(cartno);
				cvo.setUserid(userid);
				cvo.setPnum(pnum);
				cvo.setOqty(oqty);
				cvo.setStatus(status);
				
				ProductVO item = new ProductVO();
				item.setPnum(pnum);
				item.setPrice(price);
				item.setSaleprice(saleprice);
				item.setPimage1(pimage1);
				item.setPcategory_fk(pcategory_fk);
				item.setPname(pname);
				item.setPoint(point);
				
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				item.setTotalPriceTotalPoint(oqty);
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				
				cvo.setItem(item);
				
				cartList.add(cvo);
			}
			
			
		} finally {
			close();
		}
		
		return cartList;
	}// end of getCartList(String userid, int sizePerPage, int currentShowPageNo) ----------------------------

	// *** cartno로 jsp_cart 테이블(장바구니 테이블)에 있는 정보를 삭제하는 메소드 *** // 
	@Override
	public int cartnoDelete(String userid, String cartno) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			String sql = " update jsp_cart set status = 0 "
						+" where userid = ? and cartno = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, cartno);
			
			result = pstmt.executeUpdate();
			
		} finally {
			close();
		}
		
		
		return result;
		
	}// end of cartnoDelete(String userid, String cartno) --------------------------

	// *** jsp_product_imagefile 테이블에서 복수개 이미지 파일을 출력해주는 메소드  *** //
	@Override
	public List<ProductImagefileVO> getProductImagefileByPnum(String pnum) throws SQLException {
		List<ProductImagefileVO> imgFileList = null;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select imgfileno, fk_pnum, imgfilename "
						+" from jsp_product_imagefile "
						+" where fk_pnum = ? "
						+" order by imgfileno desc ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, pnum);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				
				cnt++ ;
				
				if(cnt == 1) {
					imgFileList = new ArrayList<ProductImagefileVO>();
				}
				
				int imgfileno = rs.getInt("imgfileno");
				int fk_pnum = rs.getInt("fk_pnum");
				String imgfilename = rs.getString("imgfilename");
				
				ProductImagefileVO imgvo = new ProductImagefileVO(imgfileno, fk_pnum, imgfilename);
				
				imgFileList.add(imgvo);
				
			}// end of while ------------------------
			
		} finally {
			close();
		}
		
		return imgFileList;
	}// end of getProductImagefileByPnum(String pnum) -----------------------------


	// *** jsp_category 테이블에서 카테고리코드(code)와 카테고리명(cname)을 가져오는 메소드 *** //
	@Override
	public List<CategoryVO> getCategoryList() throws SQLException {
		List<CategoryVO> categoryList = null;
		try {
			conn = ds.getConnection();
			
			String sql = " select cnum, code, cname "
						+" from jsp_category "
						+" order by cnum ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt ++;
				
				if(cnt == 1) {
					categoryList = new ArrayList<CategoryVO>();
				}
				
				int cnum = rs.getInt("cnum");
				String code = rs.getString("code");
				String cname = rs.getString("cname");
				
				CategoryVO cgvo = new CategoryVO(cnum, code, cname);
				categoryList.add(cgvo);
				
			}// end of while ----------------------------
			
		} finally {
			close();
		}
		
		return categoryList;
	}// end of getCategoryList() ----------------------------------------


	// *** jsp_product 테이블에서  code값으로 pspec 컬럼의 값(HIT, NEW, BEST)별로 상품목로드를 가져오는 추상메소드 *** //
	@Override
	public List<ProductVO> selectByPspec(String p_spec, String code) throws SQLException {
		List<ProductVO> productList = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pspec = ? and pcategory_FK = ? "
					+   "  order by pnum desc ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, p_spec);
			pstmt.setString(2, code);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;

				if(cnt==1)
					productList = new ArrayList<ProductVO>();

				int pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    ProductVO pvo = new ProductVO(pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  
			    
			    productList.add(pvo);
			    
			}// end of while-----------------
						
		} finally{
			close();
		}
				
		return productList;
	}// end of selectByPspec(String pspec, String code) ------------------------


	// *** 주문코드(명세서번호)시퀀스 값 가져오는 메소드 *** //
	@Override
	public int getSeq_jsp_order() throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select seq_jsp_order.nextval AS seq "
						+" from dual ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			result = rs.getInt("seq");
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of getSeq_jsp_order() ------------------------------------------------


	// *** 주문하기(transaction 처리) 메소드 *** //
	/*
	 	==== *** Transaction 처리하기 *** ====
	 	1. 주문개요 테이블(jsp_order)에 입력(insert)
	 	2. 주문상세 테이블(jsp_order_detail)에 입력(insert)
	 	3. 구매하는 사용자의 coin 컬럼의 값을 구매한 가격만큼 차감하고(update),
	 	   point 컬럼의 값은 구매한 포인트만큼 증가(update).
	  	4. 주문한 제품의 잔고량은 주문량 만큼 차감해야 하고(update)
	 	5. 장바구니에서 주문을 한 것이라면 장바구니 비우기(status 컬럼을 0으로 변경한다. 원래는 delete)
	 	를 해주는 DAO에서 만든 메소드 호출하기
	 */
	@Override
	public int add_Order_OrderDetail(String odrcode, String userid, int sumtotalprice, int sumtotalpoint,
			String[] pnumArr, String[] oqtyArr, String[] salepriceArr, String[] cartnoArr) throws SQLException {
		
		int n1=0, n2=0, n3=0, n4=0, n5=0;
		try {
			conn = ds.getConnection();
				
			// ==== *** Transaction 처리하기 *** ====
			// 오토커밋 해제 --> 모든DML문이 성공되었을 경우에만 commit 하고, 하나라도 실패하면 rollback;
			conn.setAutoCommit(false);
			
			// 1. 주문개요 테이블(jsp_order)에 입력(insert)
			String sql = " insert into jsp_order(odrcode, fk_userid, odrtotalPrice, odrtotalPoint, odrdate) "
						+" values(?, ?, ?, ?, default) ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, odrcode);
			pstmt.setString(2, userid);
			pstmt.setInt(3, sumtotalprice);
			pstmt.setInt(4, sumtotalpoint);
			
			n1 = pstmt.executeUpdate();
			
			if(n1 != 1) {
				conn.rollback();
				return 0;
			}
			
			if(n1 == 1) {
				// 2. 주문상세 테이블(jsp_order_detail)에 입력(insert)
				for(int i=0; i<pnumArr.length; i++) {
					
					sql = " insert into jsp_order_detail(odrseqnum, fk_odrcode, fk_pnum, oqty, odrprice, deliverStatus, deliverDate) "
						+ " values(seq_jsp_order_detail.nextval, ?, ?, ?, ?, default, default) ";
					
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, odrcode);
					pstmt.setString(2, pnumArr[i]);
					pstmt.setString(3, oqtyArr[i]);
					pstmt.setString(4, salepriceArr[i]);
					n2 = pstmt.executeUpdate();
					
					if(n2 != 1) {
						conn.rollback();
						return 0;
					}
					
				}// end of for -------------------------------------
								
			}// end of if -------------------------------------

			if(n2 == 1) {
				// 3. 구매하는 사용자의 coin 컬럼의 값을 구매한 가격만큼 차감하고(update),
			 	//    point 컬럼의 값은 구매한 포인트만큼 증가(update).
				sql = " update jsp_member set coin = coin - ?, point = point + ? "
					+ " where userid = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, sumtotalprice);
				pstmt.setInt(2, sumtotalpoint);
				pstmt.setString(3, userid);
				n3 = pstmt.executeUpdate();
				
				if(n3 != 1) {
					conn.rollback();
					return 0;
				}
								
			}// end of if --------------------------------------------------
			
			if(n3 == 1) {
				// 4. 주문한 제품의 잔고량은 주문량 만큼 차감해야 하고(update)
				for(int i=0; i<pnumArr.length; i++) {
					
					sql = " update jsp_product set pqty = pqty - ? "
						+ " where pnum = ? ";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, oqtyArr[i]);
					pstmt.setString(2, pnumArr[i]);
					
					n4 = pstmt.executeUpdate();
					
					if(n4 != 1) {
						conn.rollback();
						return 0;
					}
					
				}// end of for ---------------------------------
				
			}// end of if ---------------------------------------

			// 5. 장바구니에서 주문을 한 것이라면 장바구니 비우기(status 컬럼을 0으로 변경한다. 원래는 delete)
			if(cartnoArr != null && n4 == 1) {

				for(int i=0; i<pnumArr.length; i++) {
					sql = " update jsp_cart set status = 0 "
						+ " where cartno = ? ";
					
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, cartnoArr[i]);
					n5 = pstmt.executeUpdate();
					
					if(n5 != 1) {
						conn.rollback();
						return 0;
					}
					
				}// end of for ----------------------------------
						
			}// end of if ----------------------------------------
			
			// *** 바로 주문하기인 경우의 commit 하기 *** //
			if(cartnoArr == null && n1+n2+n3+n4 == 4) {
				conn.commit();
				return 1;
			} 
			// *** 장바구니인 경우의 commit 하기 *** //
			else if(cartnoArr != null && n1+n2+n3+n4+n5 == 5) {
				conn.commit();
				return 1;
			}
			else {
				conn.rollback();
				return 0;
			}
			
			
			
		} finally {
			close();
		}
		
	}// end of add_Order_OrderDetail(String odrcode, String userid, int sumtotalprice, int sumtotalpoint,
	 //									String[] pnumArr, String[] oqtyArr, String[] salepriceArr, String cartnoArr) -----


	// *** 제품번호들에 해당하는 제품목록을 조회해오는 추상 메소드 *** //
	@Override
	public List<ProductVO> getJumunfinishProductList(String pnumes) throws SQLException {
		List<ProductVO> productList = null;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty,"
						+"		  price, saleprice, pspec, pcontent, point, pinputdate "
						+" from jsp_product "
						+" where pnum in("+ pnumes +") ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;
				
				if(cnt == 1) {
					productList = new ArrayList<ProductVO>();
				}
			
				int pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    ProductVO pvo = new ProductVO(pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  
			    
			    productList.add(pvo);
				
				
			}
			
		} finally {
			close();
		}
		
		return productList;
	}// end of getJumunfinishProductList(String pnumes) ---------------------------------------

	// *** 유저아이디로 주문한량의 총개수를 알아오는 메소드 *** //
	@Override
	public int getUserOrderTotal(String userid) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = " select count(*) as cnt "
						+" from jsp_order_detail A join jsp_order B "
						+" on A.fk_odrcode = B.odrcode "
						+" where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd') "
						+" and fk_userid = ? "
						+" order by odrseqnum desc ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			if(bool) {
				result = rs.getInt("cnt");
			}
						
		} finally {
			close();
		}
		return result;
	}// end of getUserOrderTotal(String userid) ------------------------------------------


	// *** 유저아이디로 주문한 내용 및 주문한 제품의 정보를 가져오는 메소드 *** //
	@Override
	public List<HashMap<String, String>> getOrderList(String userid, int sizePerPage , int currentShowPageNo) throws SQLException {
		List<HashMap<String, String>> orderlist  = null;
		try {
			conn = ds.getConnection();
			String sql = " select rno, odrcode, oqty, odrprice, deliverstatus, "
						+"        odrtotalprice, odrtotalpoint, odrdate, "
						+"        pnum, pname, pimage1, price, point "
						+" from "
						+" ( "
						+"   select rownum as rno, odrcode, oqty, odrprice, deliverstatus, "
						+"          odrtotalprice, odrtotalpoint, odrdate, "
						+"          pnum, pname, pimage1, price, point "
						+"   from "
						+"   ( "
						+"     select odrcode, oqty, odrprice, deliverstatus, "
						+"            odrtotalprice, odrtotalpoint, to_char(odrdate,'yyyy-mm-dd') as odrdate, "
						+"            pnum, pname, pimage1, price, point "
						+"     from jsp_order_detail A join jsp_order B "
						+"     on A.fk_odrcode = B.odrcode "
						+"     join jsp_product C "
						+"     on A.fk_pnum = C.pnum "
						+"     where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd') ";
						
			if(!userid.equals("admin")) {
					sql += "           and fk_userid = ? ";
			}
					sql +="     order by odrseqnum desc "
						 +"   )V "
						 +" )T "
						 +" where rno between ? and ? ";
							
						
			
			pstmt = conn.prepareStatement(sql);
			if(!userid.equals("admin")) {
				pstmt.setString(1, userid);
				pstmt.setInt(2, (currentShowPageNo*sizePerPage)-(sizePerPage-1) );
				pstmt.setInt(3, (currentShowPageNo*sizePerPage) );
				
			}else {
				pstmt.setInt(1, (currentShowPageNo*sizePerPage)-(sizePerPage-1) );
				pstmt.setInt(2, (currentShowPageNo*sizePerPage) );
			}
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;
				
				if(cnt == 1) {
					orderlist = new ArrayList<HashMap<String, String>>();
				}
				
				String odrcode = rs.getString("odrcode");
				int oqty = rs.getInt("oqty");
				int odrprice = rs.getInt("odrprice");
				int deliverstatus = rs.getInt("deliverstatus");
				int odrtotalprice = rs.getInt("odrtotalprice");
				int odrtotalpoint = rs.getInt("odrtotalpoint");
				String odrdate = rs.getString("odrdate");
				int pnum = rs.getInt("pnum");
				String pname = rs.getString("pname");
				String pimage1 = rs.getString("pimage1");
				int price = rs.getInt("price");
				int point = rs.getInt("point");
				
				HashMap<String, String> map = new HashMap<String, String>();
				
				map.put("odrcode", odrcode);
				map.put("oqty", String.valueOf(oqty));
				map.put("odrprice", String.valueOf(odrprice));
				map.put("deliverstatus", String.valueOf(deliverstatus));
				map.put("odrtotalprice", String.valueOf(odrtotalprice));
				map.put("odrtotalpoint", String.valueOf(odrtotalpoint));
				map.put("odrdate", odrdate);
				map.put("pnum", String.valueOf(pnum));
				map.put("pname", pname);
				map.put("pimage1", pimage1);
				map.put("price", String.valueOf(price));
				map.put("point", String.valueOf(point));
				
				orderlist.add(map);
			}
			
			
		} finally {
			close();
		}
		return orderlist;
	}// end of getOrderList(String userid, String sizePerPage , String currentShowPageNo) ------------------------------------

	// *** 전체 주문내역의 총개수를 알아오는 메소드 *** //
	@Override
	public int getAllOrderTotal() throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			String sql = " select count(*) as cnt "
						+" from jsp_order_detail A join jsp_order B "
						+" on A.fk_odrcode = B.odrcode "
						+" where to_char(odrdate,'yyyymmdd') between to_char(add_months(sysdate,-12),'yyyymmdd') and to_char(sysdate,'yyyymmdd') "
						+" order by odrseqnum desc ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				result = rs.getInt("cnt");
			}
						
		} finally {
			close();
		}
		return result;
	}// end of getAllOrderTotal() ---------------------------------------------------


	// *** 주문코드로 유저정보를 가져오는 메소드 *** //
	@Override
	public MemberVO getMemberInfo(String ordcode) throws SQLException {
		MemberVO vo = null;
		try {
			conn = ds.getConnection();
			
			String sql = " select idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, " 
						+"        to_char(registerday, 'yyyy-mm-dd') AS registerday,status, coin,  point " 
						+" from jsp_order_detail A join jsp_order B " 
						+" on A.fk_odrcode = B.odrcode "
						+" join jsp_member C on B.fk_userid = C.userid "
						+" where odrcode = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, ordcode);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			int idx = rs.getInt("idx");
			String userid = rs.getString("userid");
			String name = rs.getString("name");
			String pwd = rs.getString("pwd");
			String email = rs.getString("email");
			String hp1 = rs.getString("hp1");
			String hp2 = rs.getString("hp2");
			String hp3 = rs.getString("hp3");
			String post1 = rs.getString("post1");
			String post2 = rs.getString("post2");
			String addr1 = rs.getString("addr1");
			String addr2 = rs.getString("addr2");
			String registerday = rs.getString("registerday");
			int status = rs.getInt("status");
			int coin = rs.getInt("coin");
			int point = rs.getInt("point");
			
			vo = new MemberVO(idx, userid, name, pwd, email, hp1, hp2, hp3, post1, post2, addr1, addr2, registerday, status);
			vo.setCoin(coin);
			vo.setPoint(point);
				
			
		} finally {
			close();
		}
		
		
		return vo;
		
	}// end of getMemberInfo(String odrcode)


	// *** 주문코드와 제품번호로 배송준비에서 시작으로 변경하는 메소드 *** //
	@Override
	public int updateDeliverStart(String odrcodePnum, int length) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			conn.setAutoCommit(false);
			
			String sql = " update jsp_order_detail set deliverstatus = 2 "
						+" where fk_odrcode || fk_pnum in ("+ odrcodePnum +")";
			pstmt = conn.prepareStatement(sql);
			int n = pstmt.executeUpdate();
			
			if(n == length) {
				conn.commit();
				result = 1;
			}else {
				conn.rollback();
				result = 0;
			}
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of updateDeliverStart(String odrcodePnum, String length)


	// *** 주문코드와 제품번호로 배송시작에서 완료로 변경하는 메소드 *** //
	@Override
	public int updateDeliverEnd(String odrcodePnum, int length) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			conn.setAutoCommit(false);
			
			String sql = " update jsp_order_detail set deliverstatus = 3 "
						+" where fk_odrcode || fk_pnum in ("+ odrcodePnum +")";
			pstmt = conn.prepareStatement(sql);
			int n = pstmt.executeUpdate();
			
			if(n == length) {
				conn.commit();
				result = 1;
			}else {
				conn.rollback();
				result = 0;
			}
			
		} finally {
			close();
		}
		
		return result;
	}// end of updateDeliverEnd(String odrcodePnum, String length)


	// ***  jsp_product 테이블에 신규제품으로 insert 되어질 "제품번호" 시퀀스를 가져오는 메소드. *** //
	@Override
	public int getPnumOfProduct() throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			
			String sql = " select seq_jsp_product_pnum.nextval AS seq "
						+" from dual ";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			rs.next();
			
			result = rs.getInt("seq");
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of getPnumOfProduct() -----------------------------------------------


	// *** 제품등록(신규상품등록)을 해주는 메소드 ** //
	@Override
	public int productInsert(ProductVO pvo) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			
			String sql = " insert into jsp_product(pnum, pname, pcategory_fk, pcompany, "
					    +"                         pimage1, pimage2, pqty, price, saleprice, " 
					    +"                         pspec, pcontent, point, pinputdate) "
					    +" values(?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,?, default) ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pvo.getPnum());
			pstmt.setString(2, pvo.getPname());
			pstmt.setString(3, pvo.getPcategory_fk());
			pstmt.setString(4, pvo.getPcompany());
			pstmt.setString(5, pvo.getPimage1());
			pstmt.setString(6, pvo.getPimage2());
			pstmt.setInt(7, pvo.getPqty());
			pstmt.setInt(8, pvo.getPrice());
			pstmt.setInt(9, pvo.getSaleprice());
			pstmt.setString(10, pvo.getPspec());
			pstmt.setString(11, pvo.getPcontent());
			pstmt.setInt(12, pvo.getPoint());
			
			result = pstmt.executeUpdate();
			
		} finally {
			close();
		}
		
		return result;
	}// end of productInsert(ProductVO pvo) 


	// *** 제품등록(신규상품등록)시 추가이미지 파일정보를 jsp_product_imagefile 테이블에 insert 해주는 메소드***//
	@Override
	public int product_imagefile_insert(int pnum, String attachFilename) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			
			String sql = " insert into jsp_product_imagefile(imgfileno, fk_pnum, imgfilename) "
					    +" values(seq_imgfileno.nextval, ?, ?) ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, pnum);
			pstmt.setString(2, attachFilename);
			result = pstmt.executeUpdate();
			
		} finally {
			close();
		}
		
		return result;
	}// end of product_imagefile_insert(String pnum, String attachFilename) -------------------------
	
	// *** 로그인한 사용자의 구매 통계 현황을 조회해주는 메소드 *** //
		@Override
		public List<HashMap<String, String>> getMyOrderStatics(String userid) throws SQLException {
			List<HashMap<String, String>> mapList = null;
			
			try {
				conn = ds.getConnection();
				
				String sql = " select v.cname, sum(jumunprice) AS SUMJUMUNPRICE,  "
							+"        round( sum(jumunprice)/( select sum(B.oqty * B.odrprice)  "
							+"                                 from jsp_order A join jsp_order_detail B  "
							+"                                 on A.odrcode = B.fk_odrcode  "
							+"                                 join jsp_product C  "
							+"                                 on B.fk_pnum = C.pnum  "
							+"                                 join jsp_category D  "
							+"                                 on C.pcategory_fk = D.code  "
							+"                                 where A.fk_userid = ? )*100, 1) AS PERCENT  "
							+" from  "
							+" (  "
							+"   select D.cname, B.oqty * B.odrprice AS JUMUNPRICE "
							+"   from jsp_order A join jsp_order_detail B "
							+"   on A.odrcode = B.fk_odrcode  "
							+"   join jsp_product C  "
							+"   on B.fk_pnum = C.pnum  "
							+"   join jsp_category D  "
							+"   on C.pcategory_fk = D.code  "
							+"   where A.fk_userid = ?  "
							+" )V  "
							+" group by v.cname  "
							+" order by percent desc  ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, userid);
				
				rs = pstmt.executeQuery();
				
				int cnt = 0;
				while(rs.next()) {
					cnt ++;
					
					if(cnt == 1) {
						mapList = new ArrayList<HashMap<String, String>>();
					}
					
					String cname = rs.getString("cname");
					String sumjumunprice = rs.getString("sumjumunprice");
					String percent = rs.getString("percent");
					
					HashMap<String, String> map = new HashMap<>();
					map.put("cname", cname);
					map.put("sumjumunprice",sumjumunprice);
					map.put("percent", percent);				
					
					mapList.add(map);
				}
				
			} finally {
				close();
			}
			
			return mapList;
		}// end of getMyOrderStatics(String userid) ------------------------------------


		// ** 제품 카테고리별 월별 판매 통계 현황을 조회해오는 메소드** //
		@Override
		public List<HashMap<String, String>> TotalOrderStatics() throws SQLException {
			List<HashMap<String, String>> mapList = null;
			
			try {
				conn = ds.getConnection();
				
				String sql = " select D.cname, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '01', B.oqty, 0) ) AS JAN, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '02', B.oqty, 0) ) AS FEB, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '03', B.oqty, 0) ) AS MAR, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '04', B.oqty, 0) ) AS APR, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '05', B.oqty, 0) ) AS MAY, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '06', B.oqty, 0) ) AS JUN, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '07', B.oqty, 0) ) AS JUL, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '08', B.oqty, 0) ) AS AUG, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '09', B.oqty, 0) ) AS SEB , "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '10', B.oqty, 0) ) AS OCT, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '11', B.oqty, 0) ) AS NOV, "
							+"        sum( decode(to_char(A.odrdate, 'mm'), '12', B.oqty, 0) ) AS DEC "
							+" from jsp_order A join jsp_order_detail B "
							+" on A.odrcode = B.fk_odrcode "
							+" join jsp_product C "
							+" on B.fk_pnum = C.pnum "
							+" join jsp_category D "
							+" on C.pcategory_fk = D.code "
							+" where to_char(A.odrdate, 'yyyy') = to_char(sysdate, 'yyyy') "
							+" group by D.cname ";
							
							
				pstmt = conn.prepareStatement(sql);
				
				rs = pstmt.executeQuery();
				
				int cnt = 0;
				while(rs.next()) {
					cnt ++;
					
					if(cnt == 1) {
						mapList = new ArrayList<HashMap<String, String>>();
					}
					
					String CNAME = rs.getString("CNAME");
					String JAN = rs.getString("JAN");
					String FEB = rs.getString("FEB");
					String MAR = rs.getString("MAR");
					String APR = rs.getString("APR");
					String MAY = rs.getString("MAY");
					String JUN = rs.getString("JUN");
					String JUL = rs.getString("JUL");
					String AUG = rs.getString("AUG");
					String SEB = rs.getString("SEB");
					String OCT = rs.getString("OCT");
					String NOV = rs.getString("NOV");
					String DEC = rs.getString("DEC");
					
					HashMap<String, String> map = new HashMap<>();
					map.put("CNAME", CNAME);
					map.put("JAN", JAN);
					map.put("FEB", FEB);
					map.put("MAR", MAR);
					map.put("APR", APR);
					map.put("MAY", MAY);
					map.put("JUN", JUN);
					map.put("JUL", JUL);
					map.put("AUG", AUG);
					map.put("SEB", SEB);
					map.put("OCT", OCT);
					map.put("NOV", NOV);
					map.put("DEC", DEC);
					
					
					mapList.add(map);
				}
				
			} finally {
				close();
			}
			
			return mapList;
		}// end of TotalOrderStatics()-------------------------------------------


		// ** jsp_like 테이블에 insert 를 해주는 메소드 ** //
		@Override
		public int insertLike(String userid, String pnum) throws SQLException {
			int result = 0;
			
			try {
				conn = ds.getConnection();
				
				String sql = " delete from jsp_dislike "
							+" where userid = ? and pnum = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				
				pstmt.executeUpdate();
				
				sql = " insert into jsp_like(userid, pnum)  "
					+ " values(?, ?) ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				
				result = pstmt.executeUpdate();
								
			} finally {
				close();
			}
			
			return result;
		}// end of insertLike(String userid, String pnum) --------------------------


		// ** jsp_like 테이블과 jsp_dislike 테이블에서 특정 제품에 대한 count(*)를 조회하는 추상 메소드 ** //
		@Override
		public HashMap<String, String> getLikeDislikeCount(String pnum) throws SQLException {
			HashMap<String, String> map = null;
			
			try {
				conn = ds.getConnection();
				String sql = " select (select count(*) "
							+"         from jsp_like "
							+"         where pnum = ?) AS LIKECNT, "
							+"         (select count(*) "
							+"         from jsp_dislike "
							+"         where pnum = ?) AS DISLIKECNT "
							+" from dual ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, pnum);
				pstmt.setString(2, pnum);
				
				rs = pstmt.executeQuery();
				
				rs.next();
				
				map = new HashMap<String, String>();
				
				String likecnt = rs.getString("likecnt");
				String dislikecnt = rs.getString("dislikecnt");
				
				map.put("likecnt", likecnt);
				map.put("dislikecnt", dislikecnt);
				
				
			} finally {
				close();
			}
			return map;
		}// end of getLikeDislikeCount(String pnum)


		// ** jsp_dislike 테이블에 insert 를 해주는 메소드 ** //
		@Override
		public int insertDislike(String userid, String pnum) throws SQLException {
int result = 0;
			
			try {
				conn = ds.getConnection();
				
				String sql = " delete from jsp_like "
							+" where userid = ? and pnum = ? ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				
				pstmt.executeUpdate();
				
				sql = " insert into jsp_dislike(userid, pnum)  "
					+ " values(?, ?) ";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				
				result = pstmt.executeUpdate();
								
			} finally {
				close();
			}
			
			return result;
		}// end of insertDislike(String userid, String pnum)---------------------------------------
	
}
