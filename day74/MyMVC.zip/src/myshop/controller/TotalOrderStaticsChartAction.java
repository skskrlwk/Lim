package myshop.controller;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import common.controller.AbstractController;
import myshop.model.InterProductDAO;
import myshop.model.ProductDAO;

public class TotalOrderStaticsChartAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		InterProductDAO dao = new ProductDAO();
		
		List<HashMap<String, String>> mapList = dao.TotalOrderStatics();
		JSONArray jsonArr = new JSONArray();
		
		if(mapList != null && mapList.size() > 0) {	
			for(HashMap<String, String> vo : mapList) {
				
				JSONObject jsonObj = new JSONObject();
				jsonObj.put("CNAME", vo.get("CNAME"));
				jsonObj.put("JAN", vo.get("JAN"));
				jsonObj.put("FEB", vo.get("FEB"));
				jsonObj.put("MAR", vo.get("MAR"));
				jsonObj.put("APR", vo.get("APR"));
				jsonObj.put("MAY", vo.get("MAY"));
				jsonObj.put("JUN", vo.get("JUN"));
				jsonObj.put("JUL", vo.get("JUL"));
				jsonObj.put("AUG", vo.get("AUG"));
				jsonObj.put("SEB", vo.get("SEB"));
				jsonObj.put("OCT", vo.get("OCT"));
				jsonObj.put("NOV", vo.get("NOV"));
				jsonObj.put("DEC", vo.get("DEC"));
				
				jsonArr.add(jsonObj);				
			}
		}
			
		String str_jsonArr = jsonArr.toString();
		
		req.setAttribute("str_jsonArr", str_jsonArr);
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/totalOrderStaticsChart.jsp");
		
	}

}
