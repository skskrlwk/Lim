package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.CartVO;
import myshop.model.ProductDAO;
import util.my.MyUtil;

public class CartListAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		ProductDAO pdao = new ProductDAO();
		MemberVO loginuser = super.getMemberLogin(req);
		// 로그인 유무 검사해주는 메소드 호출
		
		if(loginuser == null) {
			return;
		}
		
		int sizePerPage = 2;
		
		String str_currentShowPage = req.getParameter("currentShowPageNo");
		int currentShowPageNo = 0;
		
		int totalPage = 0;
		int totalCountMemo = pdao.getCartTotal(loginuser.getUserid()); //112
		totalPage = (int)Math.ceil((double)totalCountMemo / sizePerPage);
		
		
		if(str_currentShowPage == null) {
			currentShowPageNo = 1;
			
		}else {
			try {
				currentShowPageNo = Integer.parseInt(str_currentShowPage);
				
				if(totalPage < currentShowPageNo || currentShowPageNo < 1) {
					currentShowPageNo = 1;
				}
				
			} catch (NumberFormatException e) {
				currentShowPageNo = 1;
			}
			
		}
		
		
		// 로그인을 했으면 장바구니 목록을 조회해준다.
		List<CartVO> cartList = pdao.getCartList(loginuser.getUserid(), sizePerPage, currentShowPageNo);
		req.setAttribute("cartList", cartList);

		// *** 메소드로 pageBar 호출하기 *** //
		String url = "cartList.do";
		int blocksize = 2;
		
		String pageBar = MyUtil.getPageBar(url, currentShowPageNo, sizePerPage, totalPage, blocksize);	
		req.setAttribute("pageBar", pageBar);
		
		
		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/cartList.jsp");
	}

}
