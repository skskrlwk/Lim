package myshop.model;

import java.sql.*;
import java.util.*;

import javax.naming.*;
import javax.sql.DataSource;

public class ProductDAO implements InterProductDAO {
	
	private DataSource ds;
	// 객체변수 ds는 아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 이다. (import javax.sql.DataSource)
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	/* 
	  	=== ProductDAO 생성자에서 해야할 일은 === 
	   	아파치 톰캣이 제공하는 DBCP(DB Connection Pool) 객체인 ds 를 빌려오는 것이다.  
	*/
	public ProductDAO() {
		try {
			Context initContext = new InitialContext(); // javax.naming 을 import한다.
			Context envContext  = (Context)initContext.lookup("java:/comp/env");
			ds = (DataSource)envContext.lookup("jdbc/myoracle");
			
		} catch (NamingException e) {
			e.printStackTrace(); 
		}
		
	}// end of ProductDAO()---------------------------------
	

	// *** 사용한 자원을 반납하는 close() 메소드 생성하기 *** //
	public void close() {
		try {
			
			if(rs != null) {
				rs.close();
				rs = null;
			}
			
			if(pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
			
			if(conn != null) {
				conn.close();
				conn = null;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}// end of close()------------------------------------


	// *** jsp_product 테이블에서 pspec 컬럼의 값(HIT, NEW, BEST) 별로 상품 목록을 가져오는 메소드 생성하기 *** // 
	@Override
	public List<ProductVO> selectByPspec(String p_spec)	throws SQLException {
		
		List<ProductVO> productList = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pspec = ? "
					+   "  order by pnum desc ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, p_spec);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				cnt++;

				if(cnt==1)
					productList = new ArrayList<ProductVO>();

				int pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    ProductVO pvo = new ProductVO(pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  
			    
			    productList.add(pvo);
			    
			}// end of while-----------------
						
		} finally{
			close();
		}
				
		return productList;
	}// end of selectByPspec(String pspec)------------------------------------


	// *** jsp_product 테이블에서 pnum으로 제품1개의 정보를 받아오는 메소드 *** //
	@Override
	public ProductVO getProductOneByPnum(String pnum) throws SQLException {
		ProductVO vo = null;
		
		try {
			conn = ds.getConnection();
			// DBCP객체 ds를 통해 context.xml에서 이미 설정된 Connection 객체를 빌려오는 것이다.
			
			String sql = " select * "     
					+   "  from jsp_product "
					+   "  where pnum = ? ";
			
			pstmt = conn.prepareStatement(sql); 
			pstmt.setString(1, pnum);
			
			rs = pstmt.executeQuery();
			
			boolean bool = rs.next();
			
			if(bool) {
				int i_pnum = rs.getInt("pnum");
			    String pname	= rs.getString("pname");
			    String pcategory_fk = rs.getString("pcategory_fk");
			    String pcompany = rs.getString("pcompany");
			    String pimage1 = rs.getString("pimage1");
			    String pimage2 = rs.getString("pimage2");
			    int pqty = rs.getInt("pqty");
			    int price = rs.getInt("price");
			    int saleprice = rs.getInt("saleprice");
			    String pspec = rs.getString("pspec");
			    String pcontent = rs.getString("pcontent");
			    int point = rs.getInt("point");
			    String pinputdate = rs.getString("pinputdate");
			    
			    vo = new ProductVO(i_pnum, pname, pcategory_fk, pcompany, pimage1, pimage2, pqty, price, saleprice, pspec, pcontent, point, pinputdate);  			
			}
				
		} finally{
			close();
		}
		
		
		return vo;
	}// end of getProductOneByPnum(String pnum) ---------------------------------

	// *** jsp_cart 테이블(장바구니 테이블)에 물건을 입력해주는 메소드 *** //
	@Override
	public int addCart(String userid, String pnum, String oqty) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			
			/*
			 	먼저 장바구니 테이블(jsp_cart)에 새로운 제품은 넣는 것인지,
			 	아니면 또다시 제품을 추가로 더 구매하는 것인지 알기 위해서
			 	사용자가 장바구니에 넣으려고 하는 제품번호가 장바구니 테이블에
			 	이미 있는지 먼저 장바구니번호(cartno)의 값을 알아온다.
			 */
			
			String sql = " select cartno "
						+" from jsp_cart "
						+" where status = 1 and "
						+" 		 userid = ? and "
						+"		 pnum = ? "; 
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, pnum);
			
			rs = pstmt.executeQuery();
				
			if(rs.next()) {
				// 이미 장바구니 테이블에 담긴 제품이라면 update 해준다.
				int cartno = rs.getInt("cartno");
				
				sql = " update jsp_cart set oqty = oqty + ? "
					+ " where cartno = ? ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, Integer.parseInt(oqty));
				pstmt.setInt(2, cartno);
				
				result = pstmt.executeUpdate();
				
			} else {
				// 장바구니 테이블에 없는 제품이라면 insert 해준다.
				sql = " insert into jsp_cart(cartno, userid, pnum, oqty) "
					+ " values(seq_jsp_cart_cartno.nextval, ?, to_number(?), to_number(?) ) ";
			
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, pnum);
				pstmt.setString(3, oqty);
				
				result = pstmt.executeUpdate();
			}
			
		} finally {
			close();
		}
		
		return result;
	}// end of addCart(String userid, String pnum, String oqty) ----------------------------


	// *** jsp_cart 테이블(장바구니 테이블)을 조회해주는 메소드 *** //
	@Override
	public List<CartVO> getCartList(String userid) throws SQLException {
		
		List<CartVO> cartList = null;
		try {
			conn = ds.getConnection();
			
			String sql = "SELECT B.cartno, " 
						+"  B.userid, " 
						+"  B.pnum, " 
						+"  A.pname, " 
						+"  A.pcategory_fk, " 
						+"  A.pimage1, " 
						+"  A.price, " 
						+"  A.saleprice, " 
						+"  B.oqty, " 
						+"  A.point, " 
						+"  B.status " 
						+"FROM jsp_product A " 
						+"JOIN jsp_cart B " 
						+"ON A.pnum      = B.pnum " 
						+"WHERE B.userid = ? " 
						+"AND B.status   = 1 " 
						+"ORDER BY B.cartno DESC";
			
			pstmt =conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				
				cnt ++;
				if(cnt == 1) {
					cartList = new ArrayList<CartVO>();
				}
				
				int cartno = rs.getInt("cartno");
				userid = rs.getString("userid");
				int pnum = rs.getInt("pnum");
				String pname = rs.getString("pname");
				String pcategory_fk = rs.getString("pcategory_fk");
				String pimage1 = rs.getString("pimage1");
				int price = rs.getInt("price");
				int saleprice = rs.getInt("saleprice");
				int oqty = rs.getInt("oqty");
				int point = rs.getInt("point");
				int status = rs.getInt("status");
				
				CartVO cvo = new CartVO();
				cvo.setCartno(cartno);
				cvo.setUserid(userid);
				cvo.setPnum(pnum);
				cvo.setOqty(oqty);
				cvo.setStatus(status);
				
				ProductVO item = new ProductVO();
				item.setPnum(pnum);
				item.setPrice(price);
				item.setSaleprice(saleprice);
				item.setPimage1(pimage1);
				item.setPcategory_fk(pcategory_fk);
				item.setPname(pname);
				item.setPoint(point);
				
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				item.setTotalPriceTotalPoint(oqty);
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				
				cvo.setItem(item);
				
				cartList.add(cvo);
			}
			
			
		} finally {
			close();
		}
		
		return cartList;
		
	}// end of getCartList(String userid) -------------------------------------------

	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 있는 수량을 변경하는 추상 메소드 *** // 
	@Override
	public int oqtyUpdate(String userid, String cartno, String oqty) throws SQLException {
		int result = 0;
		
		try {
			conn = ds.getConnection();
			
			if(Integer.parseInt(oqty) == 0) {
				// 입력된 수량값이 0이거나 음수값일때
				String sql = " update jsp_cart set status = 0 "
						+" where userid = ? and cartno = ? ";
				
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, userid);
				pstmt.setString(2, cartno);
				
				result = pstmt.executeUpdate();
				
				
			}else {
				// 
				String sql = " update jsp_cart set oqty = ? "
						+" where userid = ? and cartno = ? ";
					
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, oqty);
				pstmt.setString(2, userid);
				pstmt.setString(3, cartno);
				
				result = pstmt.executeUpdate();
				
			}
			
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of oqtyUpdate(String userid, String cartno, String oqty)


	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 총개수를 가져오는 메소드 ** //
	@Override
	public int getCartTotal(String userid) throws SQLException {
		int result = 0;
		try {
			conn = ds.getConnection();
			String sql = " select count(*) AS CNT "
						+" from jsp_cart"
						+" where status = 1 and "
						+" 		 userid = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			
			rs = pstmt.executeQuery();
			boolean bool = rs.next();
			if(bool) {
				result = rs.getInt("CNT");
			}
			
		} finally {
			close();
		}
		
		
		return result;
	}// end of getCartTotal(String userid) ----------------------------------


	@Override
	public List<CartVO> getCartList(String userid, int sizePerPage, int currentShowPageNo) throws SQLException {
		
		List<CartVO> cartList = null;
		try {
			conn = ds.getConnection();
			
			String sql = " SELECT cartno, userid, pnum, pname, pcategory_fk, pimage1, price, saleprice, " 
						+" 		  oqty, point, status " 
						+" FROM " 
						+"  ("
						+"	 SELECT rownum AS RNO, cartno, userid, pnum, pname, pcategory_fk, " 
						+"    		pimage1, price, saleprice, oqty, point, status " 
						+"   FROM " 
						+"    ( "
						+"		SELECT B.cartno, B.userid, B.pnum, A.pname, A.pcategory_fk, A.pimage1, " 
						+"      	   A.price, A.saleprice, B.oqty, A.point, B.status " 
						+"    	FROM jsp_product A " 
						+"      JOIN jsp_cart B " 
						+"      ON A.pnum      = B.pnum " 
						+"      WHERE B.userid = ? " 
						+"      AND B.status   = 1 " 
						+"      ORDER BY B.pnum " 
						+"    )V " 
						+"  )T " 
						+" WHERE rno BETWEEN ? AND ? ";
			
			pstmt =conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setInt(2, (currentShowPageNo*sizePerPage)-(sizePerPage-1) );
			pstmt.setInt(3, (currentShowPageNo*sizePerPage));
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			while(rs.next()) {
				
				cnt ++;
				if(cnt == 1) {
					cartList = new ArrayList<CartVO>();
				}
				
				int cartno = rs.getInt("cartno");
				userid = rs.getString("userid");
				int pnum = rs.getInt("pnum");
				String pname = rs.getString("pname");
				String pcategory_fk = rs.getString("pcategory_fk");
				String pimage1 = rs.getString("pimage1");
				int price = rs.getInt("price");
				int saleprice = rs.getInt("saleprice");
				int oqty = rs.getInt("oqty");
				int point = rs.getInt("point");
				int status = rs.getInt("status");
				
				CartVO cvo = new CartVO();
				cvo.setCartno(cartno);
				cvo.setUserid(userid);
				cvo.setPnum(pnum);
				cvo.setOqty(oqty);
				cvo.setStatus(status);
				
				ProductVO item = new ProductVO();
				item.setPnum(pnum);
				item.setPrice(price);
				item.setSaleprice(saleprice);
				item.setPimage1(pimage1);
				item.setPcategory_fk(pcategory_fk);
				item.setPname(pname);
				item.setPoint(point);
				
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				item.setTotalPriceTotalPoint(oqty);
				// *** !!!!!!!!!!!! 중요함 !!!!!!!!!! *** //
				
				cvo.setItem(item);
				
				cartList.add(cvo);
			}
			
			
		} finally {
			close();
		}
		
		return cartList;
	}// end of getCartList(String userid, int sizePerPage, int currentShowPageNo) ----------------------------

	// *** cartno로 jsp_cart 테이블(장바구니 테이블)에 있는 정보를 삭제하는 메소드 *** // 
	@Override
	public int cartnoDelete(String userid, String cartno) throws SQLException {
		
		int result = 0;
		try {
			conn = ds.getConnection();
			String sql = " update jsp_cart set status = 0 "
						+" where userid = ? and cartno = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, cartno);
			
			result = pstmt.executeUpdate();
			
		} finally {
			close();
		}
		
		
		return result;
		
	}// end of cartnoDelete(String userid, String cartno) --------------------------
	

	
	
}
