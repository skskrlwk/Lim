package myshop.model;

import java.sql.SQLException;
import java.util.*;

public interface InterProductDAO {

	// *** jsp_product 테이블에서  pspec 컬럼의 값(HIT, NEW, BEST)별로 상품목로드를 가져오는 추상메소드 *** //
	List<ProductVO> selectByPspec(String pspec) throws SQLException;
	
	// *** jsp_product 테이블에서 pnum으로 제품1개의 정보를 받아오는 추상 메소드 *** //
	ProductVO getProductOneByPnum(String pnum) throws SQLException;

	// *** jsp_cart 테이블(장바구니 테이블)에 물건을 입력해주는 추상메소드 *** //
	int addCart(String userid, String pnum, String oqty) throws SQLException;
	
	// *** (페이징처리 전)jsp_cart 테이블(장바구니 테이블)을 조회해주는 추상 메소드 *** //
	List<CartVO> getCartList(String userid) throws SQLException;
	
	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 있는 수량을 변경하는 추상 메소드 *** // 
	int oqtyUpdate(String userid, String cartno, String oqty) throws SQLException;
	
	// *** 파라미터 값으로 jsp_cart 테이블(장바구니 테이블)에 총개수를 가져오는 추상 메소드 ** //
	int getCartTotal(String userid) throws SQLException;
	
	// *** (페이징처리) jsp_cart 테이블(장바구니 테이블)을 조회해주는 추상 메소드 *** //
	List<CartVO> getCartList(String userid, int sizePerPage, int currentShowPageNo) throws SQLException;
	
	// *** cartno로 jsp_cart 테이블(장바구니 테이블)에 있는 정보를 삭제하는 추상 메소드 *** // 
	int cartnoDelete(String userid, String cartno) throws SQLException;
}
