package myshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import common.controller.AbstractController;
import member.model.MemberVO;
import myshop.model.CartVO;
import myshop.model.ProductDAO;

public class CartListAction extends AbstractController {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res) throws Exception {
		
		MemberVO loginuser = super.getMemberLogin(req);
		// 로그인 유무 검사해주는 메소드 호출
		
		if(loginuser == null) {
			return;
		}
		
		// 로그인을 했으면 장바구니 목록을 조회해준다.
		ProductDAO pdao = new ProductDAO();
		List<CartVO> cartList = pdao.getCartList(loginuser.getUserid());
		
		req.setAttribute("cartList", cartList);

		super.setRedirect(false);
		super.setViewPage("/WEB-INF/myshop/cartList.jsp");
	}

}
